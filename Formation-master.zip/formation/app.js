// const express = require("express");
// const app = express();
// const products = require("./data.js");

// app.listen(5000, ()=>{
//     console.log("Server is listening on port 5000");
// })

// app.get("/api/products",(req,res)=>{ // Retourne tous les champs de chaque produit
//     res.json(products);
// });

// app.get("/api/products",(req,res)=>{
//     const partial_products = products.map(product =>{ // Ne retourne pas le champ prix de chaque produit
//         return {id : product.id, name :product.name}
//     });
//     res.json(partial_products);
// })
// app.get("/api/products",(req,res)=>{
//     const partial_products = products.map(product =>{ // Ne retourne pas le champ id de chaque produit
//         return {name : product.name, price : product.price}
//     });
//     res.json(partial_products);
// })

// app.get("/api/products/:productID",(req,res)=>{
//     const id = Number(req.params.productID);
//     const product = products.find(product => product.id ===id);
//         if(!product){
//             return res.status(404).send("Product not found"); // Si le produit n'est pas trouvé on renvoi une erreur 404
//         }
//     res.json(product);
// })

// QUERY STRING

// app.get("/api/query",(req,res) =>{
//     const name = req.query.name.toLowerCase();
//     const products_result = products.filter(product => product.name.toLowerCase().includes(name));
//     products_result.forEach(element => {
//         console.log(element);
//     });
//     if (products_result.length < 1){ // Contrôle s'il y a au moins 1 item dans le tableau
//         return res.status(200).send("No products matched your search")
//     };
//     res.json(products_result);
// })

// MIDDLEWARES

// app.get("/about",(req,res)=>{ // Ce qu'on ne veut pas faire car il faudrait le faire sur chaque route
//     console.log(req.url);
//     console.log(req.params);
//     console.log(req.query);
//     return res.send("About PAge");
// })

// const logger = (req,res,next) =>{// On met ces logs dans une fonction middleware
//     console.log(req.url);
//     console.log(req.params);
//     console.log(req.query);
//     next(); // Fonction prédéfinie Express qui redonne le contrôle aux routes appelantes
// }

// app.use(logger); // Exécute le middleware pour toutes les requêtes

// app.get("/about",(req,res)=>{
//     return res.send("About Page");
// })
// app.get('/about', logger, (req, res) => { // Ne va s'appliquer qu'à cette route spécifique
//     return res.send('About Page')
// })

// app.use('/api', logger) // Permet d'utiliser un middleware pour un chemi spécifique
// app.use([logger, auth]) // Permet d'utiliser plusieurs middleware

// Le MIDDLEWARE peut modifier l'objet req et l'objet res

// const auth = (req,res,next) => {
//     const user = req.query.user;
//     if (user === "admin"){
//         req.user = { name: "admin",id: 1};
//         next();
//     }else{
//         res.status(401).send("Unauthorised");
//     }
// }

// app.use(auth);
// app.get("/about",(req,res)=>{
//     console.log(req.user);
//     return res.send("About Page");
// });