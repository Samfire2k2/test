//CREATION D'UN API CRUD

//DIFFERENTS MESSAGES HTTP
// https://fr.wikipedia.org/wiki/Liste_des_codes_HTTP


// // 1XX - Informational code

// res.status(100) // Continue
// res.status(101) // Switching Protocols
// res.status(102) // Processing
// res.status(103) // Early Hints

// // 2XX - Success code

// res.status(200) // Ok
// res.status(201) // Created
// res.status(202) // Accepted
// res.status(203) // Non-Authoritative Information
// res.status(204) // No content
// res.status(205) // Reset content
// res.status(206) // Partial Content
// res.status(207) // Multi-Status
// res.status(208) // Already Reported
// res.status(210) // Contend Different
// res.status(226) // IM Used

// // 3XX - Redirection code

// res.status(300) // Multiple Choices
// res.status(301) // Moved Permanently
// res.status(302) // Found
// res.status(303) // See Other
// res.status(304) // Not Modified
// res.status(305) // Use Proxy
// res.status(306) // NOT USED
// res.status(307) // Temporary Redirect
// res.status(308) // Permanent Redirect
// res.status(310) // Too many Redirects

// // 4XX - Client error code

// res.status(400) // Bad request
// res.status(401) // Unauthorized
// res.status(402) // Payment Required
// res.status(403) // Forbidden
// res.status(404) // Not found

// // 5XX - Server error code

// res.status(500) // Internal Server error
// res.status(502) // Bad Gateway / Proxy Error
// res.status(503) // Service Unavailable

// CRUD API

const express = require("express");
const app = express();
const products = require("./data.js");

app.listen(5000, ()=>{
    console.log("Server is listening on port 5000");
})

app.use(express.json()) // Parse json body content

app.post("/api/products",(req,res)=>{
    const newProduct = {
        id: products.length + 1,
        name: req.body.name,
        price: req.body.price
    };
    products.push(newProduct);
    console.log(newProduct);
    res.status(201).json(newProduct);
});

app.get("/api/products",(req,res)=>{
    res.json(products);
})

app.get("/api/products/:productID",(req,res)=>{
    const id = Number(req.params.productID);
    const product = products.find(product => product.id === id);
    if (!product){
        return res.status(404).send("Product not found");
    };
    res.json(product);
});

app.put("/api/products/:productID",(req,res)=>{
    const id = Number(req.params.productID);
    const index = products.findIndex(product => product.id === id);
    if (index === -1){
        return res.status(404).send("Product not found");
    }
    const updateProduct = {
        id: products[index].id,
        name: req.body.name,
        price: req.body.price
    };
    products[index] = updateProduct;
    res.status(200).json("Product updated");
});

app.delete("/api/products/:productID",(req,res)=>{
    const id = Number(req.params.productID);
    const index = products.findIndex(product => product.id === id);
    if (index === -1){
        return res.status(404).send("Product not Found");
    };
    products.splice(index,1);
    res.status(200).json("Product deleted");
});