/* --------------------------- IMPORTS --------------------------- */

import express from "express";
import { createReadStream } from "node:fs";
import * as dotenv from "dotenv";
dotenv.config();

/* --------------------------- API ROUTES --------------------------- */

import tests_routes from "./src/routes/tests.js";
import clients_routes from "./src/routes/clients.js";
import labels_routes from "./src/routes/labels.js";
import items_routes from "./src/routes/items.js";
import relations_routes from "./src/routes/relations.js";
import relationstypes_routes from "./src/routes/relationstypes.js";

/* --------------------------- EXPRESS INIT --------------------------- */

const app = express();
const port = process.env.PORT || 3000;

/* --------------------------- MIDDLEWARE --------------------------- */

app.use(express.json()); // Used to accept data in json format
app.use(express.urlencoded({ extended: true })); // Used to decode the data send through html form

/* --------------------------- ENDPOINTS --------------------------- */

app.use("/api/tests", tests_routes); // TESTS
app.use("/api/clients", clients_routes); // CLIENTS
app.use("/api/labels", labels_routes); // LABELS
app.use("/api/items", items_routes); // ITEMS
app.use("/api/relations", relations_routes); // RELATIONS
app.use("/api/relationstypes", relationstypes_routes); // RELATIONSTYPES

/* --------------------------- SEND HTML FILE --------------------------- */

app.use(express.static("./public")); // Used to serve the public folder as a static folder

app.get("/", (req, res) => {
  const file = createReadStream("./public/assets/pages/index.html");
  res.writeHead(200, {
    "Content-Type": "text/html",
  });
  file.pipe(res);
});

/* --------------------------- SEND FORM FROM HTML FILE --------------------------- */

app.post("/mainForm", async (req, res) => {
  console.log(req.body);
  // await fetch(`http://localhost:3000/api/labels`, {
  //   method: "POST",
  //   body: JSON.stringify(req.body),
  //   headers: {
  //     "Content-type": "application/json; charset=UTF-8",
  //   },
  // });
  // console.log(req.body.item[0]);
  // console.log(req.body.item[1]);
  // console.log(JSON.stringify(req.body));

  res.redirect(303, `/`);
});

/* ---------- MODAL FORM TO ADD CLIENT ---------- */

app.post("/newClient", async (req, res) => {
  console.log(req.body);
  let content = {
    name: req.body.name.toUpperCase(),
    trigramme: req.body.trigramme.toUpperCase(),
  };
  await fetch(`http://localhost:3000/api/clients`, {
    method: "POST",
    body: JSON.stringify(content),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  });
  res.redirect(303, "/");
});

/* ---------- MODAL FORM TO ADD LABEL ---------- */

app.post("/newLabel", async (req, res) => {
  console.log(req.body);
  let content = {
    name: req.body.client + "_" + req.body.name,
  };
  console.log(content);
  // await fetch(`http://localhost:3000/api/clients`, {
  //   method: "POST",
  //   body: JSON.stringify(content),
  //   headers: {
  //     "Content-type": "application/json; charset=UTF-8",
  //   },
  // });
  res.redirect(303, "/");
});

/* --------------------------- SERVER INITIALISATION ON PORT --------------------------- */

app.listen(port, () => {
  console.log(`Server started at http://localhost:${port}`);
});

/* --------------------------- MIDDLEWARE HANDLING ERRORS --------------------------- */

const errorHandler = (err, req, res, next) => {
  // Error handling middleware functionality
  const status = err.status || 400;
  // send back an easily understandable error message to the caller
  res.status(status).send(err.message);
};

app.use(errorHandler);
