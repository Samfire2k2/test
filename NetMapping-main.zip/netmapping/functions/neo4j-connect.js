import neo4j from "neo4j-driver"; // https://neo4j.com/docs/api/javascript-driver/current/
import * as dotenv from "dotenv";
dotenv.config();

const { db_url, db_user, db_password } = process.env;

const driver = neo4j.driver(db_url, neo4j.auth.basic(db_user, db_password));

export default driver;
