export function wait(duration) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(duration);
      console.log(`Duration : ${duration} ms`);
    }, duration);
  });
}
