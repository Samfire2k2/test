import driver from "../../functions/neo4j-connect.js";

/* ----------------------- Récupérer tous les labels ----------------------- */

export const getLabels = async (req, res, next) => {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`
      CALL db.labels() YIELD label
      WHERE label STARTS WITH $client
      RETURN label
      ORDER BY label ASC
      `,{
        client:req.params.clientID
      });
    });
    const result = query.records.map((item) => item.get("label"));
    if (!result.length) {
      return res.status(404).json(`No label found`);
    }
    res.json(result);
    await session.close();
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Création d'un label ----------------------- */

export const createLabel = async (req, res, next) => {
  try {
    const session = driver.session();
    if (await alreadyExist(req, res, next)) {
      return res.status(409).json(`This label already exists`);
    }
    const label = req.body.name;
    await session.executeWrite((tx) => {
      return tx.run(`CREATE (n:${label})`);
    });
    await session.close();
    res.status(201).json(`Label ${label} created`);
  } catch (error) {
    next(error);
  }
};
/* ----------------------- Modification d'un label ----------------------- */

export const updateLabel = async (req, res, next) => {
  try {
    const oldLabel = req.body.oldLabel;
    const newLabel = req.body.newLabel;
    const session = driver.session();
    if (await doesntExist(req, res, next)) {
      return res.status(404).json(`${oldLabel} doesn't exist`);
    }
    await session.executeWrite((tx) => {
      return tx.run(`
      MATCH (n:${oldLabel})
      REMOVE n:${oldLabel}
      SET n:${newLabel}
      `);
    });
    await session.close();
    res.status(200).json(`Label updated from : ${oldLabel} to ${newLabel}`);
  } catch (error) {
    next(error);
  }
};
/* ----------------------- Suppression d'un label ----------------------- */

export const deleteLabel = async (req, res, next) => {
  try {
    const label = req.params.label;
    const session = driver.session();
    if (await doesntExist(req, res, next)) {
      return res.status(404).json(`This label doesn't exist`);
    }
    await session.executeWrite((tx) => {
      return tx.run(`
      MATCH (n:${label})
      DETACH DELETE n
      `);
    });
    await session.close();
    res.status(200).json(`Label deleted : ${label}`);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Vérification de la présence d'un client déjà créé ----------------------- */

const alreadyExist = async (req, res, next) => {
  try {
    const session = driver.session();
    const label = req.body.name;
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:${label}) RETURN n`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return result.length;
  } catch (error) {
    next(error);
  }
};

const doesntExist = async (req, res, next) => {
  try {
    const session = driver.session();
    const label = req.params.label || req.body.oldLabel;
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:${label}) RETURN n`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return !result.length;
  } catch (error) {
    next(error);
  }
};

/* --------------------------- LABELS --------------------------- */

// Retourne la liste des noeuds dans l'ordre des ID
// CALL db.labels()

// Retourne la liste des noeuds dans l'ordre alphabétique
// CALL db.labels() YIELD label
// RETURN label
// ORDER BY label ASC

// Retourne la liste des noeuds commençants par ""

// CALL db.labels() YIELD label
// WHERE label STARTS WITH 'D'
// RETURN label
// Retourne la liste des noeuds commençants par "" dans l'ordre alphabétique

// CALL db.labels() YIELD label
// WHERE label STARTS WITH 'D'
// RETURN label
// ORDER BY label
