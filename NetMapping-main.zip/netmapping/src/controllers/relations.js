import driver from "../../functions/neo4j-connect.js";
import JSON5 from "json5";

/* ----------------------- Récupérer toutes les relations d'un item ----------------------- */

export const getRelations = async (req, res, next) => {
  try {
    const id = req.params.itemID;
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n)-[r]->() WHERE elementId(n) = $id RETURN r`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("r"));
    await session.close();
    if (!result.length) {
      return res
        .status(404)
        .json(`Cant find any relation for the item with id n°${id}`);
    }
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Récupérer une seule relation à partir d'un item de départ et un d'arrivée ----------------------- */

export const getRelation = async (req, res, next) => {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH p = ()-[r]->() WHERE elementId(r) = $id RETURN r`, {
        id: req.params.relationID,
      });
    });
    const result = query.records.map((item) => item.get("r"));
    if (!result.length) {
      return res.status(404).json(`Relation not found`);
    }
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Création d'une relation entre deux items ----------------------- */

export const createRelation = async (req, res, next) => {
  try {
    const relation = req.body.type;
    const session = driver.session();
    if (await alreadyExist(req, res, next)) {
      return res.status(409).json(`This relation already exists`);
    }
    const query = await session.executeWrite((tx) => {
      return tx.run(
        `MATCH (a) WHERE elementId(a) = $itemStart
      MATCH (b) WHERE elementId(b) = $itemEnd
      CREATE (a)-[r:${relation} $properties]->(b) RETURN r`,
        {
          properties: req.body.properties,
          itemStart: req.body.itemStart,
          itemEnd: req.body.itemEnd,
        }
      );
    });
    const result = query.records.map((item) => item.get("r"));
    await session.close();
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Modification des propriétés d'une relation à partir de son ID ----------------------- */

export const updateRelation = async (req, res, next) => {
  try {
    const id = req.params.relationID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Relation n°${id} not found`);
    }
    const session = driver.session();
    const query = await session.executeWrite((tx) => {
      return tx.run(
        `MATCH ()-[rel]->() WHERE elementId(rel) = $id SET rel = $properties RETURN rel`,
        {
          properties: req.body.properties,
          id: id,
        }
      );
    });
    const result = query.records.map((item) => item.get("rel"));
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Suppression d'une relation à partir de son ID ----------------------- */

export const deleteRelation = async (req, res, next) => {
  try {
    const id = req.params.relationID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Relation n°${id} not found`);
    }
    const session = driver.session();
    await session.executeWrite((tx) => {
      return tx.run(`MATCH ()-[r]->() WHERE elementId(r) = $id DELETE r`, {
        id: id,
      });
    });
    await session.close();
    res.status(200).json(`Relation n°${id} deleted`);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Vérification de l'existence d'un ID pour le PUT et le DELETE ----------------------- */

async function idDoesntExist(id, next) {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH ()-[r]->() WHERE elementId(r) = $id RETURN r`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("r"));
    await session.close();
    return !result.length;
  } catch (error) {
    next(error);
  }
}

/* ----------------------- Vérification de la présence d'une relation déjà créée ----------------------- */

const alreadyExist = async (req, res, next) => {
  try {
    const session = driver.session();
    const properties = JSON5.stringify(req.body.properties);
    const relation = req.body.type;
    const query = await session.executeRead((tx) => {
      return tx.run(
        `MATCH (a) WHERE elementId(a) = $itemStart
      MATCH (b) WHERE elementId(b) = $itemEnd
      MATCH (a)-[r:${relation} ${properties}]->(b) RETURN r`,
        {
          properties: req.body.properties,
          itemStart: req.body.itemStart,
          itemEnd: req.body.itemEnd,
        }
      );
    });
    const result = query.records.map((item) => item.get("r"));
    await session.close();
    return result.length;
  } catch (error) {
    next(error);
  }
};
