import driver from "../../functions/neo4j-connect.js";
import JSON5 from "json5";

/* ----------------------- Récupérer tous les items d'un client ----------------------- */

export const getItems = async (req, res, next) => {
  try {
    const label = req.params.label;
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:${label}) RETURN n ORDER BY n.name`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    if (!result.length) {
      return res.status(404).json(`Cant find any ${label}`);
    }
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Récupérer un seul item à partir de son ID ----------------------- */

export const getItem = async (req, res, next) => {
  try {
    const id = req.params.itemID;
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n) WHERE elementId(n) = $id RETURN n`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    if (!result.length) {
      return res.status(404).json(`Item n°${id} not found`);
    }
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Création d'un item ----------------------- */

export const createItem = async (req, res, next) => {
  try {
    const label = req.body.label;
    const session = driver.session();
    if (await alreadyExist(req, res, next)) {
      return res.status(409).json(`This item already exists`);
    }
    const query = await session.executeWrite((tx) => {
      return tx.run(`CREATE (n:${label} $properties) RETURN n`, {
        properties: req.body.properties,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Modification d'un item à partir de son ID ----------------------- */

export const updateItem = async (req, res, next) => {
  try {
    const id = req.params.itemID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Item n°${id} not found`);
    }
    const session = driver.session();
    const query = await session.executeWrite((tx) => {
      return tx.run(
        `MATCH (n) WHERE elementId(n) = $id SET n = $properties RETURN n`,
        {
          properties: req.body,
          id: id,
        }
      );
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Suppression d'un item à partir de son ID ----------------------- */

export const deleteItem = async (req, res, next) => {
  try {
    const id = req.params.itemID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Item n°${id} not found`);
    }
    const session = driver.session();
    await session.executeWrite((tx) => {
      return tx.run(`MATCH (n) WHERE elementId(n) = $id DETACH DELETE n`, {
        id: id,
      });
    });
    await session.close();
    res.status(200).json(`Item n°${id} deleted`);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Vérification de l'ID pour le PUT et le DELETE ----------------------- */

async function idDoesntExist(id, next) {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n) WHERE elementId(n) = $id RETURN n`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return !result.length;
  } catch (error) {
    next(error);
  }
}

/* ----------------------- Vérification de la présence d'un item déjà créé ----------------------- */

const alreadyExist = async (req, res, next) => {
  try {
    const session = driver.session();
    const properties = JSON5.stringify(req.body);
    const label = req.params.label;
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:${label} ${properties}) RETURN n`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return result.length;
  } catch (error) {
    next(error);
  }
};
