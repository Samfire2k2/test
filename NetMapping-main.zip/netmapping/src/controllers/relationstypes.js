import driver from "../../functions/neo4j-connect.js";

/* ----------------------- Récupérer tous les types de relation pour un client ----------------------- */

export const getRelationsTypes = async (req, res, next) => {
  try {
    const client = req.params.client;
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(
        `CALL db.relationshipTypes()
      YIELD relationshipType AS relations
      WHERE relations STARTS WITH $client
      RETURN relations
      ORDER BY relations ASC`,
        {
          client: client,
        }
      );
    });
    const result = query.records.map((item) => item.get("relations"));
    await session.close();
    if (!result.length) {
      return res.status(404).json(`Cant find any ${client}`);
    }
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Suppression d'une relation à partir de son ID ----------------------- */

export const deleteRelationsTypes = async (req, res, next) => {
  try {
    const relation = req.params.relation;
    if (await idDoesntExist(relation, next)) {
      return res.status(404).json(`${relation} not found`);
    }
    const session = driver.session();
    await session.executeWrite((tx) => {
      return tx.run(`MATCH ()-[r:${relation}]->() DELETE r`);
    });
    await session.close();
    res.status(200).json(`${relation} deleted`);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Vérification de l'existence d'une relation pour le DELETE ----------------------- */

async function idDoesntExist(relation, next) {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH ()-[r:${relation}]->() RETURN r`);
    });
    const result = query.records.map((item) => item.get("r"));
    await session.close();
    return !result.length;
  } catch (error) {
    next(error);
  }
}
