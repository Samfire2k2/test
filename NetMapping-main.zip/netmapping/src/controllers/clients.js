import driver from "../../functions/neo4j-connect.js";
import JSON5 from "json5";

/* ----------------------- Récupérer tous les clients ----------------------- */

export const getClients = async (req, res, next) => {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:CLIENT) RETURN n ORDER BY n.name`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    if (!result.length) {
      return res.status(404).json(`Cant find any client`);
    }
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Récupérer un seul client à partir de son ID ----------------------- */

export const getClient = async (req, res, next) => {
  try {
    const id = req.params.clientID;
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:CLIENT) WHERE elementId(n) = $id RETURN n`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    if (!result.length) {
      return res.status(404).json(`Client n°${id} not found`);
    }
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Création d'un client ----------------------- */

export const createClient = async (req, res, next) => {
  try {
    const session = driver.session();
    if (await alreadyExist(req, res, next)) {
      return res.status(409).json(`Client déjà créé avec ces paramètres`);
    }
    const query = await session.executeWrite((tx) => {
      return tx.run(`CREATE (n:CLIENT $properties) RETURN n`, {
        properties: req.body,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Modification d'un client à partir de son ID ----------------------- */

export const updateClient = async (req, res, next) => {
  try {
    const id = req.params.clientID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Client n°${id} not found`);
    }
    const session = driver.session();
    const query = await session.executeWrite((tx) => {
      return tx.run(
        `MATCH (n:CLIENT) WHERE elementId(n) = $id SET n = $properties RETURN n`,
        {
          properties: req.body,
          id: id,
        }
      );
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Suppression d'un client à partir de son ID ----------------------- */

export const deleteClient = async (req, res, next) => {
  try {
    const id = req.params.clientID;
    if (await idDoesntExist(id, next)) {
      return res.status(404).json(`Client n°${id} not found`);
    }
    const session = driver.session();
    await session.executeWrite((tx) => {
      return tx.run(
        `MATCH (n:CLIENT) WHERE elementId(n) = $id DETACH DELETE n`,
        {
          id: id,
        }
      );
    });
    await session.close();
    res.status(200).json(`Client n°${id} deleted`);
  } catch (error) {
    next(error);
  }
};

/* ----------------------- Vérification de l'ID pour le PUT et le DELETE ----------------------- */

async function idDoesntExist(id, next) {
  try {
    const session = driver.session();
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:CLIENT) WHERE elementId(n) = $id RETURN n`, {
        id: id,
      });
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return !result.length;
  } catch (error) {
    next(error);
  }
}

/* ----------------------- Vérification de la présence d'un client déjà créé ----------------------- */

const alreadyExist = async (req, res, next) => {
  try {
    const session = driver.session();
    const properties = JSON5.stringify(req.body);
    const query = await session.executeRead((tx) => {
      return tx.run(`MATCH (n:CLIENT ${properties}) RETURN n`);
    });
    const result = query.records.map((item) => item.get("n"));
    await session.close();
    return result.length;
  } catch (error) {
    next(error);
  }
};
