import driver from "../../functions/neo4j-connect.js";
import JSON5 from "json5";

/* ----------------------- Récupérer tous les tests ----------------------- */

export const getTests = async (req, res) => {
  const session = driver.session();
  const query = await session.executeRead((tx) => {
    return tx.run(`MATCH (n:TEST) RETURN n ORDER BY n.name`);
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  if (!result.length) {
    return res.status(404).json(`Can't find any test`);
  }
  res.status(200).json(result);
};

/* ----------------------- Récupérer un seul test à partir de son ID ----------------------- */

export const getTest = async (req, res) => {
  const id = req.params.testID;
  const session = driver.session();
  const query = await session.executeRead((tx) => {
    return tx.run(`MATCH (n:TEST) WHERE elementId(n) = $id RETURN n`, {
      id: id,
    });
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  if (!result.length) {
    return res.status(404).json(`Test n°${id} not found`);
  }
  res.status(200).json(result);
};

/* ----------------------- Création d'un test ----------------------- */

export const createTest = async (req, res) => {
  const session = driver.session();
  if (await alreadyExist(req,res)){
    return res.status(409).json(`Test déjà créé avec ces paramètres`);
  }
  const query = await session.executeWrite((tx) => {
    return tx.run(`CREATE (n:TEST $properties) RETURN n`, {
      properties: req.body,
    });
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  res.status(201).json(result);
};

/* ----------------------- Modification d'un test à partir de son ID ----------------------- */

export const updateTest = async (req, res) => {
  const id = req.params.testID;
  if (await idDoesntExist(id)) {
    return res.status(404).json(`Test n°${id} not found`);
  }
  const session = driver.session();
  const query = await session.executeWrite((tx) => {
    return tx.run(
      `MATCH (n:TEST) WHERE elementId(n) = $id SET n = $properties RETURN n`,
      {
        properties: req.body,
        id: id,
      }
    );
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  res.status(200).json(result);
};

/* ----------------------- Suppression d'un test à partir de son ID ----------------------- */

export const deleteTest = async (req, res) => {
  const id = req.params.testID;
  if (await idDoesntExist(id)) {
    return res.status(404).json(`Test n°${id} not found`);
  }
  const session = driver.session();
  await session.executeWrite((tx) => {
    return tx.run(`MATCH (n:TEST) WHERE elementId(n) = $id DETACH DELETE n`, {
      id: id,
    });
  });
  await session.close();
  res.status(200).json(`Test n°${id} deleted`);
};

/* ----------------------- Vérification de l'ID pour le PUT et le DELETE ----------------------- */

async function idDoesntExist(id) {
  const session = driver.session();
  const query = await session.executeRead((tx) => {
    return tx.run(`MATCH (n:TEST) WHERE elementId(n) = $id RETURN n`, {
      id: id,
    });
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  return !result.length;
}

/* ----------------------- Vérification de la présence d'un test déjà créé ----------------------- */

const alreadyExist = async (req,res) => {
  const session = driver.session();
  const properties = JSON5.stringify(req.body);
  const query = await session.executeRead((tx) => {
    return tx.run(`MATCH (n:TEST ${properties}) RETURN n`);
  });
  const result = query.records.map((item) => item.get("n"));
  await session.close();
  return result.length;
};
