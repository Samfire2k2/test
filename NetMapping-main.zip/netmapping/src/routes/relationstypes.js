import express from "express";
const router = express.Router();

import {
  getRelationsTypes,
  deleteRelationsTypes,
} from "../controllers/relationstypes.js";

router.get("/:client", getRelationsTypes);
router.delete("/:relation", deleteRelationsTypes);

export default router;
