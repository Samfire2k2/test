import express from "express";
const router = express.Router();

import {
  getRelations,
  getRelation,
  createRelation,
  updateRelation,
  deleteRelation,
} from "../controllers/relations.js";

router.get("/item/:itemID", getRelations);
router.get("/:relationID", getRelation);
router.post("/", createRelation);
router.put("/:relationID", updateRelation);
router.delete("/:relationID", deleteRelation);

export default router;
