import express from "express";
const router = express.Router();

import {
  getItems,
  getItem,
  createItem,
  updateItem,
  deleteItem,
} from "../controllers/items.js";

router.get("/label/:label", getItems);
router.get("/:itemID", getItem);
router.post("/", createItem);
router.put("/:itemID", updateItem);
router.delete("/:itemID", deleteItem);

export default router;
