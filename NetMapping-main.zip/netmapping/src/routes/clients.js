import express from "express";
const router = express.Router();

import {
  getClients,
  getClient,
  createClient,
  updateClient,
  deleteClient,
} from "../controllers/clients.js";

router.get("/", getClients);
router.get("/:clientID", getClient);
router.post("/", createClient);
router.put("/:clientID", updateClient);
router.delete("/:clientID", deleteClient);

export default router;
