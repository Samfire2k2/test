import express from "express";
const router = express.Router();

import {
  getTests,
  getTest,
  createTest,
  updateTest,
  deleteTest,
} from "../controllers/tests.js";

router.get("/", getTests);
router.get("/:testID", getTest);
router.post("/", createTest);
router.put("/:testID", updateTest);
router.delete("/:testID", deleteTest);

export default router;
