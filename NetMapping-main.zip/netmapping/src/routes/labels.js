import express from "express";
const router = express.Router();

import {
  getLabels,
  createLabel,
  updateLabel,
  deleteLabel,
} from "../controllers/labels.js";

router.get("/:clientID", getLabels);
router.post("/", createLabel);
router.put("/", updateLabel);
router.delete("/:label", deleteLabel);

export default router;
