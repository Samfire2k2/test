export async function getOptionsOnSelectChanges(idFrom, idTo, myFunction) {
  const optionSelected = document.querySelector(idFrom);
  await optionSelected.addEventListener("change", () => {
    document.querySelector(idTo).length = 1;
    myFunction(optionSelected.value, idTo);
  });
}

export async function resetOptions(idFrom, id1, id2, id3) {
  const optionSelected = document.querySelector(idFrom);
  await optionSelected.addEventListener("change", () => {
    document.querySelector(id1).length = 1;
    document.querySelector(id2).length = 1;
    document.querySelector(id3).length = 1;
  });
}

export async function showItemOnPage(idFrom, idTo) {
  const optionSelected = document.querySelector(idFrom);
  await optionSelected.addEventListener("change", () => {
    const optionIndex = optionSelected.selectedIndex;
    if (isInPage(document.querySelector(".itemSelected"))) {
      document.querySelector(".itemSelected").remove();
    }
    const myDiv = document.createElement("div");
    myDiv.innerHTML = optionSelected.options[optionIndex].text;
    myDiv.id = optionSelected.value;
    myDiv.className = "itemSelected";
    document.querySelector(idTo).appendChild(myDiv);
  });
}

export function isInPage(node) {
  return document.body.contains(node);
}
