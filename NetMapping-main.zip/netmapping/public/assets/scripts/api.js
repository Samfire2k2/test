export async function fetchLabels(client, labels) {
  await fetch(`http://localhost:3000/api/labels/${client}`)
    .then((response) => response.json())
    .then((data) => {
      data.map((item) => {
        const option = document.createElement("option");
        option.innerHTML = item.slice(4); // Enlève les premiers caractères
        option.value = item;
        document.querySelector(labels).appendChild(option);
      });
    });
}
export async function fetchClients() {
  await fetch("http://localhost:3000/api/clients")
    .then((response) => response.json())
    .then((data) => {
      data.map((item) => {
        const option = document.createElement("option");
        option.innerHTML = item.properties.name;
        option.value = item.properties.trigramme;
        document.querySelector("#clients").appendChild(option);
      });
    });
}
export async function fetchItems(label, items) {
  await fetch(`http://localhost:3000/api/items/label/${label}`)
    .then((response) => response.json())
    .then((data) => {
      data.map((item) => {
        const option = document.createElement("option");
        option.innerHTML = item.properties.name;
        option.value = item.elementId;
        document.querySelector(items).appendChild(option);
      });
    });
}
export async function fetchRelationsTypes(client) {
  await fetch(`http://localhost:3000/api/relationstypes/${client}`)
    .then((response) => response.json())
    .then((data) => {
      data.map((item) => {
        const option = document.createElement("option");
        option.innerHTML = item.slice(4);
        option.value = item;
        document.querySelector("#relations").appendChild(option);
      });
    });
}
