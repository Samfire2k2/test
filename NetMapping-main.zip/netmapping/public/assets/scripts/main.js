import {
  fetchClients,
  fetchItems,
  fetchLabels,
  fetchRelationsTypes,
} from "./api.js";
import {
  getOptionsOnSelectChanges,
  resetOptions,
  showItemOnPage,
  isInPage,
} from "./selects.js";

/* ------------------------------------ Selects ------------------------------------ */

fetchClients();
getOptionsOnSelectChanges("#clients", "#labelsStart", fetchLabels);
getOptionsOnSelectChanges("#labelsStart", "#itemsStart", fetchItems);
getOptionsOnSelectChanges("#clients", "#labelsEnd", fetchLabels);
getOptionsOnSelectChanges("#labelsEnd", "#itemsEnd", fetchItems);
getOptionsOnSelectChanges("#clients", "#relations", fetchRelationsTypes);

resetOptions("#clients", "#itemsStart", "#itemsEnd", "#relation-property");
showItemOnPage("#itemsStart", "#section-2");

/* ------------------------------------ Modaux ------------------------------------ */

const dialog = document.querySelectorAll("dialog");

dialog.forEach((item) => {
  item.addEventListener("click", (e) => {
    const dialogDimensions = item.getBoundingClientRect();
    if (
      e.clientX < dialogDimensions.left ||
      e.clientX > dialogDimensions.right ||
      e.clientY < dialogDimensions.top ||
      e.clientY > dialogDimensions.bottom
    ) {
      item.close();
    }
  });
});

/* ------------------- New client ------------------- */

const openButtonNewClient = document.querySelector(".new-client-open");
const closeButtonNewClient = document.querySelector(".new-client-close");
const modalNewClient = document.querySelector(".new-client-modal");

openButtonNewClient.addEventListener("click", (e) => {
  e.preventDefault();
  modalNewClient.showModal();
});
closeButtonNewClient.addEventListener("click", (e) => {
  e.preventDefault();
  modalNewClient.close();
});

/* ------------------- New label ------------------- */

const openButtonNewLabel = document.querySelectorAll(".new-label-open");
const closeButtonNewLabel = document.querySelector(".new-label-close");
const modalNewLabel = document.querySelector(".new-label-modal");

openButtonNewLabel.forEach((item) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    modalNewLabel.showModal();
  });
});

closeButtonNewLabel.addEventListener("click", (e) => {
  e.preventDefault();
  modalNewLabel.close();
});

/* ------------------- New item ------------------- */

const openButtonNewItem = document.querySelectorAll(".new-item-open");
const closeButtonNewItem = document.querySelector(".new-item-close");
const modalNewItem = document.querySelector(".new-item-modal");

openButtonNewItem.forEach((item) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    modalNewItem.showModal();
  });
});

closeButtonNewItem.addEventListener("click", (e) => {
  e.preventDefault();
  modalNewItem.close();
});

/* ------------------- New relation type ------------------- */

const newRelationType = document.querySelector(".new-relation-type");

newRelationType.addEventListener("click", (e) => {
  e.preventDefault();
  const inputInPage = document.querySelector("#newRelationInput");
  if (isInPage(inputInPage)) {
    inputInPage.remove();
    document.querySelector("#relations").removeAttribute("disabled");
    newRelationType.innerHTML = "+";
    newRelationType.style.backgroundColor = "#fff";
    return;
  }
  newRelationType.innerHTML = "-";
  newRelationType.style.backgroundColor = "#E1013C";
  document.querySelector("#relations").setAttribute("disabled", "");
  const newInput = document.createElement("input");
  newInput.setAttribute("id", "newRelationInput");
  newInput.setAttribute("name", "relation");
  newInput.setAttribute("placeholder", "Nouvelle relation");
  newInput.classList.add("form-element", "wider");
  const relations = document.querySelector(".relation-type");
  relations.after(newInput);
  newInput.focus();
});

/* ------------------- New property ------------------- */

document.querySelector(".new-property").addEventListener("click", (e) => {
  e.preventDefault();
  const response = prompt("Nom de la propriété");
  if (response) {
    const myDiv = document.createElement("div");
    myDiv.classList.add("select-and-new");
    const newProperty = document.createElement("input");
    newProperty.classList.add("form-element");
    newProperty.setAttribute("name", `[properties][${response}]`);
    newProperty.setAttribute("placeholder", response);
    myDiv.append(newProperty);
    const deleteButton = document.createElement("button");
    deleteButton.classList.add("add-button", "delete-button");
    deleteButton.innerHTML = "-";
    myDiv.append(deleteButton);
    document.querySelector(".properties-container").prepend(myDiv);
    newProperty.focus();
    deleteButton.addEventListener("click", (e) => {
      e.preventDefault();
      deleteButton.parentElement.remove();
    });
  } else {
    return;
  }
});
