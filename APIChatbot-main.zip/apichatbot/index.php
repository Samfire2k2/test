<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/style.css">
    <title>Documentation API</title>
</head>
<body>
    <h1>
        API ChatBot
    </h1>
    <main>
    <section>
            <h2>
                Tous les postes
            </h2>
            <div class="container">
                <p class="method method-get">
                    GET
                </p>
                <div class="container-details">
                    <div class="details">
                        <p>
                            Retourne les offres selon le poste
                        </p>
                        <p>
                            Endpoint: /global/poste.php
                        </p>
                    </div>
                    <div class="example">
                        <p>
                            poste={Nom du poste}
                        </p>
                        <a href="http://localhost/apichatbot/global/poste.php?poste=infirmier" target="_blank">
                            http://localhost/apichatbot/global/poste.php?poste=infirmier
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <h2>
                Secteur
            </h2>
            <div class="container">
                <p class="method method-get">
                    GET
                </p>
                <div class="container-details">
                    <div class="details">
                        <p>
                            Retourne les offres selon le secteur d'activité
                        </p>
                        <p>
                            Endpoint: /offre/secteur.php
                        </p>
                    </div>
                    <div class="example">
                        <p>
                            secteur={Nom du secteur d'activité}
                        </p>
                        <a href="http://localhost/apichatbot/offre/secteur.php?secteur=btp" target="_blank">
                            http://localhost/apichatbot/offre/secteur.php?secteur=btp
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <h2>
                Villes
            </h2>
            <div class="container">
                <p class="method method-post">
                    POST
                </p>
                <div class="container-details">
                    <div class="details">
                        <p>
                            Retourne les offres selon le secteur d'activité et le code postal
                        </p>
                        <p>
                            Endpoint: /offre/villes.php
                        </p>
                    </div>
                    <div class="example">
                        <p>
                            Données à envoyer au format JSON: </br>
                            {</br>
                                "secteur": "Nom du secteur souhaité",</br>
                                "codesPostaux": [</br>
                                    Code Postal n°1,</br>
                                    Code Postal n°2,</br>
                                    Code Postal n°3</br> ] </br>
                            }
                        </p>
                        <a href="http://localhost/apichatbot/offre/villes.php" target="_blank">
                            http://localhost/apichatbot/offre/villes.php
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <h2>
                Contrats
            </h2>
            <div class="container">
                <p class="method method-post">
                    POST
                </p>
                <div class="container-details">
                    <div class="details">
                        <p>
                            Retourne les offres selon le secteur d'activité, le code postal et le type de contrat
                        </p>
                        <p>
                            Endpoint: /offre/contrats
                        </p>
                    </div>
                    <div class="example">
                        <p>
                            Données à envoyer au format JSON: </br>
                            {</br>
                                "secteur": "Nom du secteur souhaité",</br>
                                "codesPostaux": [</br>
                                    Code Postal n°1,</br>
                                    Code Postal n°2,</br>
                                    Code Postal n°3</br>],</br>
                                "contrats": [</br>
                                    Type de contrat n°1,</br>
                                    Type de contrat n°2,</br>
                                    Type de contrat n°3</br> ] </br>
                            }
                        </p>
                        <a href="http://localhost/apichatbot/offre/contrats.php" target="_blank">
                            http://localhost/apichatbot/offre/contrats.php
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <h2>
                Poste
            </h2>
            <div class="container">
                <p class="method method-post">
                    POST
                </p>
                <div class="container-details">
                    <div class="details">
                        <p>
                            Retourne les offres selon le secteur d'activité, le code postal, le type de contrat et le poste
                        </p>
                        <p>
                            Endpoint: /offre/poste
                        </p>
                    </div>
                    <div class="example">
                        <p>
                            Données à envoyer au format JSON: </br>
                            {</br>
                                "secteur": "Nom du secteur souhaité",</br>
                                "poste": "Nom du poste souhaité",</br>
                                "codesPostaux": [</br>
                                    Code Postal n°1,</br>
                                    Code Postal n°2,</br>
                                    Code Postal n°3</br>],</br>
                                "contrats": [</br>
                                    Type de contrat n°1,</br>
                                    Type de contrat n°2,</br>
                                    Type de contrat n°3</br> ] </br>
                            }
                        </p>
                        <a href="http://localhost/apichatbot/offre/poste.php" target="_blank">
                            http://localhost/apichatbot/offre/poste.php
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>