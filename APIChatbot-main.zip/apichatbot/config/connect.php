<?php

$dbhost = "192.168.99.21";
$dbname = "jobplus";
$dbuser = "readOnlyJobPlus";
$dbpwd = "M66m%M2f@wdHR7gN";

try{
    $db = new PDO("mysql:host=".$dbhost.";dbname=".$dbname.";charset=utf8",$dbuser,$dbpwd);
}
catch(Exception $e){
    die("Error :".$e->getMessage());
}