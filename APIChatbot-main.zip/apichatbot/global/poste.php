<?php
  // Headers nécessaires pour l'envoi des données
  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Methods: GET");
  header("Acces-Control-Max-Age: 3600");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-Width");

  if ($_SERVER["REQUEST_METHOD"] == "GET"){
    if (!empty($_GET["poste"])){ // Vérification de l'existence des variables dans l'URL
      $poste = htmlspecialchars($_GET["poste"]);
      // Connexion à la base de données si la méthode utilisée est bien la méthode GET
      require_once("../config/connect.php");
      $stmt = $db -> prepare (
        "SELECT libelle
        FROM job_ref_offres_qualifications 
        WHERE libelle LIKE :poste;");
      $stmt->execute([":poste" => "%$poste%"]);
      $results = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      http_response_code(200);
      echo json_encode($results);
    }else{
      http_response_code(400);
      echo json_encode(["message" => "Paramètres absents de la requête"]);
    }
  }else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode n'est pas autorisée"]);
  }