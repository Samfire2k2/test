<?php
  // Headers nécessaires pour l'envoi des données
  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Methods: GET");
  header("Acces-Control-Max-Age: 3600");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-Width");

  if ($_SERVER["REQUEST_METHOD"] == "GET"){
    // On vérifie la présence de la variable dans l'URL sinon on retourne une réponse au client
    if (empty($_GET["secteur"])){
      echo json_encode(["message" => "Paramètres absents de la requête"]);
      return http_response_code(400);
    };
    // Connexion à la base de données si la méthode utilisée est bien la méthode GET
    require_once("../config/connect.php");
    $secteur = htmlspecialchars($_GET["secteur"]);
    $stmt = $db -> prepare (
      "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse
      FROM job_base_offres jbo
      JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id 
      WHERE jrs.libelle = :secteur
      AND jbo.publiee = 1
      AND jbo.publiee_site_carriere = 1
      ORDER BY jbo.id DESC;"
    );
    $stmt->execute([":secteur" => $secteur]);
    $results = $stmt -> fetchAll(PDO::FETCH_ASSOC);
    http_response_code(200);
    echo json_encode($results);
  }else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode n'est pas autorisée"]);
  }