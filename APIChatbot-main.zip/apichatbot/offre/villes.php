<?php
  // Headers nécessaires pour l'envoi des données
  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Methods: GET");
  header("Acces-Control-Max-Age: 3600");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-Width");

  if ($_SERVER["REQUEST_METHOD"] == "POST"){

    $params = (array) json_decode(file_get_contents('php://input'), TRUE);

    foreach($params as $key => $value){
        if($key == "secteur"){
            $secteur = htmlspecialchars($value);
        }
        if($key == "codesPostaux"){
            foreach($value as $k => $v){
                $postcodePOST[$k] = $v;
            }
        }
    }

    if (empty($params) || empty($secteur) || empty($postcodePOST)){
      echo json_encode(["message" => "Paramètres absents de la requête"]);
      return http_response_code(400);
    };
    foreach ($postcodePOST as $key => $value){
      if (empty($postcodePOST[$key])){
        echo json_encode(["message" => "Code postal absent de la requête"]);
        return http_response_code(400);
      }
    }

    // Connexion à la base de données si la méthode utilisée est bien la méthode POST
    require_once("../config/connect.php");

    $postcode_params = "";
    foreach($postcodePOST as $key => $value){
      $key = ":codesPostaux".$key;
      $postcode_params .= ($postcode_params ? "," : "") . $key;
      $postcode[$key] = htmlspecialchars($value);
    };

    $stmt = $db -> prepare (
        "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse
        FROM job_base_offres jbo
        JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id
        WHERE jrs.libelle = :secteur
        AND jbo.code_postal IN ($postcode_params)
        AND jbo.publiee = 1
        AND jbo.publiee_site_carriere = 1
        ORDER BY jbo.id DESC;"
    );
    $params = [":secteur" => $secteur];
    $stmt->execute(array_merge($params,$postcode));
    $results = $stmt -> fetchAll(PDO::FETCH_ASSOC);
    http_response_code(200);
    echo json_encode($results, JSON_PRETTY_PRINT);
  }else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode n'est pas autorisée"]);
  }