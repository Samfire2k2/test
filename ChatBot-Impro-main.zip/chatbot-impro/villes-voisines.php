<?php

add_action('rest_api_init', function () {
    register_rest_route('api', '/villes-voisines', array(
        'methods' => 'GET',
        'callback' => 'mon_plugin_api_callback',
        'args' => array(
            'cp' => array(
                'type' => 'string',
                'required' => true
            ),
            'rayon' => array(
                'type' => 'int',
                'require' => true
            )
        )
    ));
});


function mon_plugin_api_callback($request)
{
    // Récupérer les paramètres depuis la requête
    $params = $request->get_params();

    // Récupérer les valeurs des paramètres dynamiques
    $cp = $params['cp'];
    $rayon = $params['rayon'];

    // Construire l'URL de l'API avec les paramètres dynamiques
    $url = 'https://www.villes-voisines.fr/getcp.php?cp=' . $cp . '&rayon=' . $rayon . '&' . http_build_query($params);

    // Appeler l'API avec wp_remote_get()
    $response = wp_remote_get($url);

    // Vérifier si la requête s'est bien déroulée
    if (is_wp_error($response)) {
        // Erreur lors de l'appel à l'API
        $error_message = $response->get_error_message();
        return new WP_Error('api_error', $error_message);
    } else {
        // Récupérer la réponse de l'API
        $body = wp_remote_retrieve_body($response);

        // Convertir la réponse en objet JSON
        $data = json_decode($body);

        // Retourner les données en format JSON
        return rest_ensure_response($data);
    }
}
