/* =========== APPARITION DES MESSAGES ========== */

const messagesBot = document.getElementById("messagesBot");
const bodyBot = document.getElementById("bodyBot");
const choicesElement = document.getElementsByClassName("choices");
const messageBot = document.getElementsByClassName("messageBot");
let selectedSector;
let selectedCity;
let selectedDepartment;
let selectedRadius;
let selectedContracts = [];
let selectedPostCode;
let selectedJob;
let firstMessage;
let randomQuestion;
let responsesForRandomQuestion;
let showResultMessage;
let reformulationQuestion;
let postQuestion;
let citiesOffers;
let resultChoices;
let postOffers;
let interimChoice;
let citiesAroundRadius;
let postCodesOffers;

// Clique sur le bouton du chatbot
async function onClickInBot() {
    // Disparition du bouton et de la bulle
    button.style.display = "none";
    bubble.style.display = "none";
    // Déployement du chatbot
    boobot.style.display = "block";

    // Apparition du premier message de Bienvenue
    window.setTimeout(async function () {
        firstMessage = await callApiForMessage(1, 0);
        createMessageChecked(firstMessage);
    }, 1000)

    // Apparition de la question concernant le secteur
    window.setTimeout(async function () {
        // Question du secteur
        createMessageChecked(await callApiForQuestionResponses(2));
    }, 1500)

    // Apparition des choix de réponses du secteur et question suivante après le clique
    window.setTimeout(async function () {
        // Choix du secteur
        responsesToDisplayChecked(await callApiForQuestionResponses(2, true));
        // Question sur la ville
        questionAfterClick(await callApiForMessage(3, 0));
    }, 2000)
}

function inputEnabled() {
    sendMessage.style.cursor = "pointer";
    inputBot.disabled = false;
}

function inputDisabled() {
    sendMessage.style.cursor = "auto";
    inputBot.disabled = true;
}

let questionAlreadyExit = false;

// Fonction qui permet d'appeler la question qui se produit après la sélection d'un choix
function questionAfterClick(question, response) {
    // Vérification de cette vriable afin de ne faire ce code qu'une fois et qu'il ne se réexecute pas en cas de réouverture de chatbot
    if (!questionAlreadyExit) {
        questionAlreadyExit = true;

        const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1].childNodes;

        // Boucle sur les éléments de réponses des choix précédents
        for (let element of lastResponse) {

            // Ajout de la classe visited (changement de propriétés CSS) pour l'élément sélectionné et passage dans la fonction suivante
            element.addEventListener("click", async function () {

                const lastQuestion = document.getElementsByClassName('messageBot')[document.getElementsByClassName('messageBot').length - 1];

                if (lastQuestion.textContent.includes("secteur")) {
                    selectedSector = element.textContent;
                }

                desactivateButtons(element);

                getLoader();

                // Apparition de la question random
                window.setTimeout(async function () {
                    messageDisplay = false;
                    createMessage(await callApiForRandomQuestion());
                    sendMessage.style.cursor = "auto";
                }, 2000);

                // Apparition des choix de réponses qui s'accordent à la question précédente et passage à la question suivante
                window.setTimeout(async function () {
                    inputDisabled();
                    responsesDisplay = false;
                    // Réponses de la question random
                    responsesToDisplay(await callApiForQuestionResponses(13, true));
                    conditionForContinuOrStop(element, question, response);
                }, 3000);
            })
        }
    }
}

function desactivateButtons(choice) {
    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];
    for (const b of lastResponse.children) {
        b.disabled = true;
        b.style.cursor = "auto";
        b.classList.add("no-hover");
    }
    if (choice.classList.contains("validateVisited")) {
        choice.classList.remove("no-hover");
    } else {
        choice.classList.add("visited");
    }
}

function activateButtons() {
    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];
    for (const b of lastResponse.children) {
        b.disabled = false;
        b.classList.remove("visited");
        b.classList.remove("validateVisited");
        b.style.cursor = "pointer";
        b.classList.remove("no-hover");
    }
}

let isModifyButtonClicked = false;

// Fonction permettant de définir ce qui se passe pour chaque cas de réponse à la question random
function conditionForContinuOrStop(select, question, response) {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1].childNodes;

    // Boucle sur les choix de réponses
    for (let el of lastResponse) {
        // Au clique sur un éléments
        el.addEventListener("click", async function (event) {
            // Si mon élément sélectionné est "affiner ma recherche", désactivation des boutons et ajout de la classe "visited" sur l'élément sélectionné
            if (event.currentTarget.textContent === "Affiner ma recherche") {
                getLoader();

                desactivateButtons(el);

                // Appel de la question suivante au bout de 1 seconde et si la question porte sur la localisation ou sur le poste, appel de la fonction inputEnable
                window.setTimeout(function () {
                    const lastQuestion = document.getElementsByClassName("messageBot")[document.getElementsByClassName("messageBot").length - 1];
                    // console.log(lastQuestion.textContent);
                    if (!lastQuestion.textContent.includes("ville")) {
                        createMessageChecked(question);
                    }
                    const lastQuestion2 = document.getElementsByClassName("messageBot")[document.getElementsByClassName("messageBot").length - 1];
                    // console.log(lastQuestion2.textContent);
                    if (lastQuestion2.textContent.includes("ville") || lastQuestion2.textContent.includes("poste")) {

                        inputEnabled();
                        inputEnable();

                        // Sinon, affichaque des réponses qui correspondent à la question
                    } else if (lastQuestion2.textContent.includes("contrat")) {

                        window.setTimeout(function () {
                            responsesDisplay = false;
                            responsesToDisplay(response);
                            multiSelect();

                        }, 1000);
                    }
                }, 2000);
                // Sinon si la réponse sélectionnée est "modifier ma réponse", suppression de la question random et de ses réponses et disponibilité des anciens choix    
            } else if (event.currentTarget.textContent === "Modifier ma réponse ") {
                // Cette condition vérifie si le bouton à dejà été cliqué où non pour qu'à la réouverture du chatbot, on ne supprime pas plus d'éléments que ceux demandés
                if (!el.isModifyButtonClicked) {
                    el.isModifyButtonClicked = true;

                    selectedContracts = [];

                    const choicesElementDiv = document.getElementsByClassName("choices");
                    const lastThreeResponses = [...choicesElementDiv].slice(-3);

                    lastThreeResponses.forEach((element) => element.parentNode.removeChild(element));

                    const messageBotQuestion = document.getElementsByClassName("messageBot");
                    const theLastQuestion = [...messageBotQuestion].slice(-1);

                    theLastQuestion.forEach((element) => element.parentNode.removeChild(element));

                    const lastChild = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];

                    lastChild.parentNode.removeChild(lastChild);
                    activateButtons();
                }
            } else if (event.currentTarget.textContent === "Afficher les résultats correspondants") {

                const lastQuestion = document.getElementsByClassName('messageBot')[document.getElementsByClassName('messageBot').length - 2];

                getLoader();
                desactivateButtons(el);

                if (lastQuestion.textContent.includes("secteur")) {
                    window.setTimeout(async function () {
                        onlyOneMessage = false;
                        createOfferCards(await callApiForOffersBySector(selectedSector));
                    }, 2000);
                } else if (lastQuestion.textContent.includes("ville")) {
                    window.setTimeout(async function () {
                        onlyOneMessage = false;
                        createOfferCards(await callApiForOffersByLocation(selectedSector, postCodesOffers));
                    }, 2000);
                } else if (lastQuestion.textContent.includes("contrat")) {
                    interimChangeAtCTT();
                    onlyOneMessage = false;
                    createOfferCards(await callApiForOffersByContract(selectedSector, postCodesOffers, selectedContracts));
                }


                // console.log('J\'envois mes données dans la BDD');
                // await callApiForRegisterData(selectedSector, selectedCity, selectedDepartment, selectedRadius, selectedJob, selectedContracts);
            }
        }, { once: true });
    }
}

function interimChangeAtCTT() {
    interimChoice = selectedContracts.find(element => element === "Intérim");
    if (interimChoice !== undefined) {
        selectedContracts.splice(0, 1, "CTT");
    }
}

// Au clique sur la croix, fermeture du chatbot
function onClickInClosingCross() {
    boobot.style.display = "none";
    button.style.display = "block";
}

/* =========== ENVOI DE MESSAGE ========== */

// Récupération du fomulaire par son id dans une variable et ajout d'un écouteur d'évennement à l'envoi de celui-ci
function inputEnable() {
    const botForm = document.getElementById("botForm");
    const lastQuestion = document.getElementsByClassName('messageBot')[document.getElementsByClassName('messageBot').length - 1];

    // Enlèvement de l'écouteur d'évènement de la localisation et du poste au cas ou ceux-ci seraient déjà présents avant de rentrer dans la condition
    botForm.removeEventListener("submit", handleUserResponseLocation);
    botForm.removeEventListener("submit", handleUserResponsePost);

    // Vérification de la dernière question posée, pour mettre un écouteur d'évènement différent, selon la question
    if (lastQuestion.textContent === "Donnez moi le nom de la ville dans laquelle vous souhaitez travailler ?") {
        botForm.addEventListener("submit", handleUserResponseLocation);

    } else if (lastQuestion.textContent === "Quel poste souhaitez-vous occuper, plus précisément ?") {
        botForm.addEventListener("submit", handleUserResponsePost)
    }
}

function handleUserResponsePost(event) {
    event.preventDefault();

    createElementResponseUser();
    let postEntitled = inputBot.value;
    inputBot.value = "";
    inputDisabled();
    getLoader();
    checkPostEntitled(postEntitled);
}

const sendMessage = document.getElementById("send");
let inputBot = document.getElementById("inputBot");

// Désactivation du champ utilisateur
inputDisabled();

// Empêche l'envoi de la valeur de l'input vide
function verifInput() {
    if (inputBot.value != "") {
        sendMessage.disabled = false;
    } else {
        sendMessage.disabled = true;
    }
}

// Correspond à l'index courant des données de localisation cherchées dans l'API
let currentIndex = 0;
let inputValue;
let postCode;

// Fonction qui gère le comportement à l'envoi de la localisation de l'utilisateur
async function handleUserResponseLocation(event) {
    // Empêche le rechargement automatique de la page au moment de l'envoi du formulaire
    event.preventDefault();

    createElementResponseUser();

    getLoader();

    inputDisabled();
    inputValue = inputBot.value;
    inputBot.value = "";

    const dataLocation = await callApiForLocation(inputValue);

    if (currentIndex >= dataLocation.length) {
        currentIndex = 0;
    }

    if (dataLocation.length === 0) {
        getLoader();

        window.setTimeout(async function () {
            messageDisplay = false;
            // Ville non trouvé, demande de reformulation
            createMessage(await callApiForMessage(3, 1));
            sendMessage.style.cursor = "pointer";
            inputBot.disabled = false;
        }, 2000);

        currentIndex = 0;
    } else {
        let city = dataLocation[currentIndex].city;
        let department = dataLocation[currentIndex].department;
        postCode = dataLocation[currentIndex].postCode;

        requestForReformulation(dataLocation, city, department);
    }
    // Remplacement de la valeur de l'input par vide
    inputBot.value = "";
}

// Vérification selon la réception de l'entrée utilisateur
function requestForReformulation(dataLocation, city, department) {
    // Vérification que qu'il y a une dernière réponse utilisateur, qu'il y a une donnée dans l'API à l'index courant, si la donnée de l'API correspond à l'input, si l'input correspond à la dernière réponse utilisateur et si l'index courant est inférieur à l'index maximum du tableau de données de l'API
    let lastResponse = document.getElementsByClassName("responsesUser")[document.getElementsByClassName("responsesUser").length - 2];
    let cityEqualInput;
    let lastRespEqualInput;

    if (city.trim().match(new RegExp(inputBot.value, "i"))) {
        cityEqualInput = true;
    }

    if (lastResponse && inputValue.match(new RegExp(lastResponse.textContent, "i"))) {
        lastRespEqualInput = true;
    }

    if ((!lastResponse || lastRespEqualInput) && dataLocation[currentIndex] && cityEqualInput) {

        reformulation(city, department, dataLocation);
        currentIndex++;

    } else if (lastResponse && !lastRespEqualInput) {

        currentIndex = 0;
        city = dataLocation[currentIndex].city;
        department = dataLocation[currentIndex].department;
        reformulation(city, department, dataLocation);
        currentIndex++;
    }
}

// Reformulation avec la ville et de département et choix de réponses à cette reformulation
function reformulation(dataCity, dataDepartment, dataLocation) {
    getLoader();

    window.setTimeout(function () {
        messageDisplay = false;
        createMessage(`Si j’ai bien compris, vous recherchez dans la ville de ${dataCity} dans le département ${dataDepartment} ? 🤔`);
        inputDisabled();
        selectedCity = dataCity;
        selectedDepartment = dataDepartment;
        selectedPostCode = postCode;
    }, 2000);

    window.setTimeout(async function () {
        reformulationQuestion = await callApiForQuestionResponses(5, true);
        responsesToDisplayChecked(reformulationQuestion);
        conditionForReformulationOfLocation(dataLocation);
    }, 2000);
}

// Choix de l'utilisateur sur oui ou non après la reformulation du bot
function conditionForReformulationOfLocation() {

    const lastChoices = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1].childNodes;
    // Boucle parconrant les choix de la reformulation
    for (el of lastChoices) {
        (function (el) {
            el.addEventListener("click", function (event) {

                // Si l'utilisateur clique sur oui, affichage de la question sur le rayon en passant par la question random puis à la question suivante
                if (el.textContent.includes("Oui")) {

                    desactivateButtons(el);

                    getLoader();
                    currentIndex = 0;

                    window.setTimeout(async function () {
                        // Question des rayons
                        createMessageChecked(await callApiForQuestionResponses(7));
                    }, 1500);

                    window.setTimeout(async function () {
                        // Choix des rayons
                        responsesToDisplayChecked(await callApiForQuestionResponses(7, true));
                        questionAlreadyExit = false;

                        suiteOfRadius();
                    }, 2000);

                    // Sinon on redemande la nom de la ville    
                } else {

                    desactivateButtons(el);

                    getLoader();
                    window.setTimeout(async function () {
                        messageDisplay = false;
                        // Demande de reformulation si l'utilisateur a mis "non"
                        createMessage(await callApiForMessage(3, 3));
                        inputEnabled();
                    }, 2000);

                    // Supprimer en BDD la dernière réponse donnée pour la dernière question affichée
                }
            });
        })(el);
    }
}

function suiteOfRadius() {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1].childNodes;

    // Boucle sur les éléments de réponses des choix précédents (ici, les rayons)
    for (let element of lastResponse) {
        element.addEventListener("click", async function () {

            getLoader();
            desactivateButtons(element);

            selectedRadius = element.textContent.substring(0, 2);
            citiesAroundRadius = await callApiForRadius(selectedPostCode[0], selectedRadius);

            // Transformation de l'objet en tableau d'objet afin de pouvoir faire des map dessus
            const arr = Array.from(Object.values(citiesAroundRadius));
            citiesOffers = arr.map(cities => cities.nom_commune);
            postCodesOffers = arr.map(cities => cities.code_postal);

            // Apparition de la question random
            window.setTimeout(async function () {
                messageDisplay = false;
                createMessage(await callApiForRandomQuestion());
                sendMessage.style.cursor = "auto";
            }, 2000);

            // Apparition des choix de réponses qui s'accordent à la question précédente et passage à la question suivante
            window.setTimeout(async function () {
                inputDisabled();
                responsesDisplay = false;

                // Réponses de la question random
                responsesToDisplay(await callApiForQuestionResponses(13, true));
                conditionForContinuOrStop(element, await callApiForQuestionResponses(8), await callApiForQuestionResponses(8, true));
            }, 2500);
        })
    }
}

// Fonction qui permet de sélectionner plusieurs choix de réponses (dans le cas du type de contrat)
function multiSelect() {
    let lastChildChoicesBot = document.getElementsByClassName('choicesBot')[document.getElementsByClassName('choicesBot').length - 1];
    const choicesElements = lastChildChoicesBot.children;

    let numElementsVisited = 0;
    // Boucle sur les derniers éléments de choix
    for (choice of choicesElements) {
        (function (choice) {
            choice.addEventListener('click', async function () {

                // Si le bouton cliqué n'est pas "Valider", j'ajoute la classe visited et j'augmente ma variable numElementsVisited, sinon si le bouton est "Valider" et que la variable est égal ou supérieur à un ou plus, je lui met la classe validateVisited et j'appelle la question suivante
                if (choice.textContent !== "Valider") {
                    choice.classList.toggle('visited');

                    choice.classList.contains('visited') ? numElementsVisited++ : numElementsVisited--;

                } else if (choice.textContent === "Valider" && numElementsVisited >= 1) {

                    choice.classList.add('validateVisited');
                    for (c of choicesElements) {
                        if (c.classList.contains('visited')) selectedContracts.push(c.textContent);
                    }

                    desactivateButtons(choice);

                    getLoader();

                    // Apparition de la question random
                    window.setTimeout(async function () {
                        messageDisplay = false;
                        createMessage(await callApiForRandomQuestion());
                    }, 2000);

                    // Apparition des choix de réponses qui s'accordent à la question précédente et passage à la question suivante
                    window.setTimeout(async function () {
                        responsesDisplay = false;
                        // Réponses pour la question random
                        responsesToDisplay(await callApiForQuestionResponses(13, true));
                        // responsesToDisplay(await callApiForQuestionResponses(13, true));
                        conditionForContinuOrStop(choice, await callApiForMessage(6, 0));
                    }, 3000);
                    numElementsVisited = 0;
                }
            });
        })(choice);
    }
}

let postDoesntExist = 1;
async function checkPostEntitled(postName) {
    let apiResponse = await callApiForCheckPostEntitled(postName);
    getLoader();

    if (apiResponse.length > 0) {
        interimChangeAtCTT();
        selectedJob = postName;
        postOffers = await callApiForOffersByPost(selectedSector, postCodesOffers, selectedContracts, selectedJob);
        onlyOneMessage = false;
        createOfferCards(postOffers);

    } else {
        console.log(postDoesntExist);
        selectedJob = undefined;
        if (postDoesntExist >= 3) {

            messageDisplay = false;
            window.setTimeout(async function () {
                createMessage(`Le nom du poste n'est toujours pas valide 😅, mais voici les offres correspondantes à vos précédentes recherches pour le secteur ${selectedSector}, dans un rayon de ${selectedRadius} km autour de la ville de ${selectedCity}, et dont le/s contrat/s sont ${selectedContracts} 😉`);

                interimChangeAtCTT();
                onlyOneMessage = false;
                getLoader();
                window.setTimeout(async function () {
                    createOfferCards(await callApiForOffersByContract(selectedSector, postCodesOffers, selectedContracts));
                }, 2000)
            }, 2000)
        } else {
            window.setTimeout(async function () {
                messageDisplay = false;
                createMessage(`Le poste recherché n'existe pas 🤨, merci de me donner un autre nom de poste`);
                postDoesntExist++;
                inputEnabled();
            }, 2000)
        }
    }
}