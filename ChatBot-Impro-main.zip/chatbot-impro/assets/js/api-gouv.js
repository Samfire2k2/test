/* =========== APPEL API GOUVERNEMENT ========== */
let responsesIfNoConnexion;
let offerPageLink = "https://candidat.abalone-emploi.com/offres-d-emploi";

// Appel à l'API du gouvernement pour les noms de villes et de départements
async function callApiForLocation(city) {
    const url = `https://geo.api.gouv.fr/communes?nom=${city}&boost=population&fields=code,nom,codesPostaux,departement`;
    try {
        const response = await fetch(url);
        const datas = await response.json();
    
        let dataLocation = datas.map((data) => {
            return {
                city: data.nom,
                department: data.departement["nom"],
                postCode: data.codesPostaux
            }
        })
        return dataLocation;
    } catch {
        // En cas d'erreur, demande de reformulation
        inputBot.value = "";
        inputBot.disabled = true;
        bodyBot.scrollTop = bodyBot.scrollHeight;
        getLoader();
        window.setTimeout(function () {
            messageDisplay = false;
            createMessage(`Un problème de connexion à l'API est survenu, veuillez recommencer votre recherche ultérieurement ou vous diriger vers la page "offres" de notre site internet`);
            window.setTimeout(function () {
                responsesDisplay = false;
                responsesIfNoConnexion = responsesToDisplay(["Recommencer ma recherche", "Notre page d'offres"]);

                let offerPage = responsesIfNoConnexion.children[1];

                aElement = document.createElement("a");
                aElement.href = offerPageLink;
                aElement.innerText = offerPage.innerText;
                aElement.classList.add("choices");
                aElement.style.display = "block";

                offerPage.replaceWith(aElement);

                choiceButtonIfNoConnect();
            }, 1000);
        }, 2000);

        throw new Error(
            "L'appel API a échoué"
        );
    }
}

function choiceButtonIfNoConnect() {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];
    const lastCards = document.getElementsByClassName("cards")[document.getElementsByClassName("cards").length - 1];

    for (choice of lastResponse.children) {
        (function (choice) {
            choice.addEventListener("click", function () {

                choice.classList.add("visited");

                if (choice.textContent.includes("Recommencer")) {
                    startAgainButton(lastCards);
                }
            },);
        })(choice)
    }
}

// Recherche du code postal de la ville recherchée
async function searchPostCode(city) {
    const url = `https://api-adresse.data.gouv.fr/search/?q=${city}&type=municipality`;

    try {
        const response = await axios.get(url, {
            params : {
                ville : city
            }
        })
        
        // return response.data.features[0].properties.postcode;
        return response;
    } catch (error) {
        console.log(error);
    }
}


// console.log(await callApiForRadius("44100", 10));
// console.log(await searchPostCode("nantes"));