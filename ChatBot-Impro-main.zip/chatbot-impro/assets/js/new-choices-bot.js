/* =========== CREATION DES CHOIX DE REPONSE ========== */

// Création et affichages des choix de réponses avec vérification d'unicité de la liste
function responsesToDisplayChecked(array) {

    // Vérification que les réponses ne sont pas déjà présentes dans le DOM avant de créer les éléments
    for (let j = 0; j < array.length; j++) {
        for (let k = 0; k < choicesElement.length; k++) {
            if (array[j] === choicesElement[k].textContent) {
                return;
            }
        }
    }

    // Création de la div qui contiendra les choix proposés par le bot, ajout d'une classe et placement dans le DOM
    const choicesBot = document.createElement("div");
    choicesBot.classList.add("choicesBot");
    messagesBot.append(choicesBot);

    let i = 0;
    // Boucle qui parcours les réponses du chatbot et qui crée des éléments html pour chaque proposition
    while (i < array.length) {
        const choiceElement = document.createElement("button");
        choiceElement.classList.add("choices");
        choiceElement.textContent = array[i];
        choicesBot.append(choiceElement);
        messagesBot.append(choicesBot);
        choiceElement.style.display = "block";
        bodyBot.scrollTop = bodyBot.scrollHeight;
        i++;
    }
    return choicesBot;
}

let responsesDisplay = false;

// Création et affichages des choix de réponses sans vérification d'unicité de la liste
function responsesToDisplay(array) {

    if (!responsesDisplay) {
        responsesDisplay = true;
        
        // Création de la div qui contient les choix proposés par le bot, ajout d'une classe et placement dans le DOM
        const choicesBot = document.createElement("div");
        choicesBot.classList.add("choicesBot");
        messagesBot.append(choicesBot);

        let i = 0;
        // Boucle qui parcours les réponses du chatbot et qui crée des éléments html pour chaque proposition
        while (i < array.length) {
            const choiceElement = document.createElement("button");
            choiceElement.classList.add("choices");
            choiceElement.textContent = array[i];
            choicesBot.append(choiceElement);
            messagesBot.append(choicesBot);
            choiceElement.style.display = "block";
            bodyBot.scrollTop = bodyBot.scrollHeight;
            if (choiceElement.textContent === "Valider") {
                choiceElement.classList.add("validate")
            }
            i++;
        }
        return choicesBot;
    }
}