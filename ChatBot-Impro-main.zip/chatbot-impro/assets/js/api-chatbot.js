/* =========== APPEL API CHATBOT ========== */

// Appel de l'API Wordpress sur une route personnalisée qui donne accès aux questions par étape
async function callApiForMessage(step, index) {
    try {
        const response = await axios.get(`http://localhost/chatbot/wp-json/bot/api/questions/etape/${step}`);
        return response.data[index].entitled;
    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée qui donne accès aux questions et à leur réponse par id
async function callApiForQuestionResponses(id, arg = false) {

    try {
        const response = await axios.get(`http://localhost/chatbot/wp-json/bot/api/questions/${id}/reponses`);

        if(id === 7 && arg ) {
            let results = response.data['choices'].map(result => result + " km");
            return results
        }
        // Si le deuxième argument de la fonction est vrai, on affiche les choix de réponses et si il est faux (par défaut), on affiche la question
        if (arg) {
            return response.data['choices'];
        }
        return response.data['entitled'];

    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée qui donne accès à une question aléatoire
async function callApiForRandomQuestion() {
    try {
        const response = await axios.get(`http://localhost/chatbot/wp-json/bot/api/questions/random`);

        return response.data[0].entitled;
    } catch (error) {
        console.log(error);
    }
}

// Envoi de données dans la base de données Wordpress pour enregistrer des statistiques
async function callApiForRegisterData(sectorUser, cityUser, departmentUser, radiusUser, jobUser, typesUser = []) {
    try {
        const response = await axios.post(`http://localhost/chatbot/wp-json/api/bot/creation/visiteur`, {
            sector: sectorUser,
            city: cityUser,
            department: departmentUser,
            radius: radiusUser,
            job: jobUser,
            types: typesUser
        })
        return response;
    } catch (error) {
        console.log(error);
    }
}

/* =========== APPEL API JOBPLUS ========== */

// Appel de l'API Wordpress sur une route personnalisée sur la base de données JobPLus qui filtre les offres par secteur d'activité 
async function callApiForOffersBySector(sector) {
    try {
        // const response = await axios.get(`http://localhost/chatbot/wp-json/api/job/offre/secteur`, {
        const response = await axios.get(`http://localhost/apichatbot/offre/secteur.php`, {
            params: {
                secteur: sector
            }
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée sur la base de données JobPlus qui filtre les offres par localisation
async function callApiForOffersByLocation(sector, postCodes) {
    try {
        // const response = await axios.post(`http://localhost/chatbot/wp-json/api/job/offre/ville`, {
        const response = await axios.post(`http://localhost/apichatbot/offre/villes.php`, {
                secteur: sector,
                codesPostaux: postCodes
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée sur la base de données JobPlus qui filtre les offres par contrats
async function callApiForOffersByContract(sector, postCodes, contracts) {
    try {
        const response = await axios.post(`http://localhost/apichatbot/offre/contrats.php`, {
                secteur: sector,
                codesPostaux: postCodes,
                contrats: contracts
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée sur la base de données JobPlus qui va vérifier si le nom de poste existe
async function callApiForCheckPostEntitled(poste) {
    try {
        const response = await axios.get(`http://localhost/apichatbot/global/poste.php`, {
            params: {
                poste: poste
            }
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

// Appel de l'API Wordpress sur une route personnalisée sur la base de données JobPlus qui filtre les offres par contrats
async function callApiForOffersByPost(sector, postCodes, contracts, post) {
    try {
        const response = await axios.post(`http://localhost/apichatbot/offre/poste.php`, {
                secteur: sector,
                codesPostaux: postCodes,
                contrats: contracts,
                poste: post
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

async function callApiForRadius(cp, rayon) {
    try {
        const response = await axios.get(`http://localhost/chatbot/wp-json/api/villes-voisines?`, {
            params: {
                cp: cp,
                rayon: rayon
            }
        });
        return response.data;
    } catch (error) {
        console.log(error);
    }
}