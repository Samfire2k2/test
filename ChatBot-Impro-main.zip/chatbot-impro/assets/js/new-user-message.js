/* =========== CREATION DES MESSAGES UTILISATEURS ========== */

// Création et affichage d'un élément à l'envoi d'un message dans l'input
function createElementResponseUser() {

    //Création d'une div qui, ajout d'une classe et placement dans le DOM, celle-ci contiendra les réponses utilisateurs
    const responsesUser = document.createElement("div");
    responsesUser.classList.add("responsesUser");
    messagesBot.append(responsesUser);

    // Création d'un élément paragraphe, ajout d'une classe à cet élément, affectation de la valeur de l'input à l'élément que l'on vient de créer et placement du paragraphe dans le DOM
    const newUserMessage = document.createElement("p");
    newUserMessage.classList.add("responseUser");
    newUserMessage.textContent = inputBot.value;
    responsesUser.append(newUserMessage);

    // Descend la scrollbar au plus bas à chaque message envoyé
    bodyBot.scrollTop = bodyBot.scrollHeight;
}