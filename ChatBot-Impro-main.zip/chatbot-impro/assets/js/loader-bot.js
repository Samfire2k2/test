/* =========== LOADER ========== */

// Récuperation des points de chargement
const loader = document.getElementsByClassName("dot-pulse");

// Fonction d'ajout des points de chargement
function getLoader() {
    loader[0].style.display = "block";
}

// Fonction d'enlèvement des points de chargement
function removeLoader() {
    loader[0].style.display = "none";
}
