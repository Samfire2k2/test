/* =========== CREATION CARTES D'OFFRES ========== */
let maxArray;
const cards = document.createElement("div");
cards.classList.add("cards");
let responses;
let noResultMessage;
let noResultChoices;
// Lien d'inscription candidat sur abalone
let registrationLink = "https://candidat.abalone-emploi.com/mon-compte";
let onlyOneMessage = false;
let messageForShowOffers;
let codeSecteur;

// Apparition des cartes d'offres et des boutons qui suivent
async function createOfferCards(data) {

    if (!onlyOneMessage) {


        onlyOneMessage = true;

        maxArray = data.length;

        if (maxArray > 100) {
            maxArray = 100;
        }

        if (data.length >= 100) {
            messageForShowOffers = `${data.length} offres correspondent à votre demande ✅ (affichées ici: 100 max)`;
        } else if (maxArray === 1) {
            messageForShowOffers = `${data.length} offre correspond à votre demande ✅`;
        } else {
            messageForShowOffers = `${data.length} offres correspondent à votre demande ✅`;
        }
        getLoader();

        if (responses === undefined && maxArray > 0) {

            messageDisplay = false;
            createMessage(messageForShowOffers);

            createElementsInOfferCard(data);
            responsesDisplay = false;
            resultChoices = await callApiForQuestionResponses(10, true);
            responses = responsesToDisplay(resultChoices);

            const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];

            let seeMoreChoice = choicesElement[choicesElement.length - 1];

            codeSectorValue();

            createLink(seeMoreChoice, `https://candidat.abalone-emploi.com/offres-d-emploi?mots_cles=&secteur=${codeSecteur}`);

            // Suppression du bouton "Voir Plus" si le nombre d'offres total est inférieur ou égal à 4
            if (maxArray <= 100 && maxArray === data.length) {
                lastResponse.removeChild(lastResponse.childNodes[2]);
            }

            choiceButtonAfterOffers(data);
        } else if (maxArray === 0) {
            noResultMessage = await callApiForQuestionResponses(12);
            messageDisplay = false;
            createMessage(noResultMessage);

            noResultChoices = await callApiForQuestionResponses(12, true);
            responsesDisplay = false;
            responses = responsesToDisplay(noResultChoices);

            registerButton = responses.children[2];

            createLink(registerButton, registrationLink);

            callAgenceButton = responses.children[3];

            callAgenceButton.disabled = true;
            callAgenceButton.style.backgroundColor = "#fbfbfb";
            callAgenceButton.style.color = "initial";
            callAgenceButton.style.cursor = "auto";
            choiceButtonIfNoResult();
        }
    }
}

// Création des cartes d'offres
function createElementsInOfferCard(data) {
    cards.innerHTML = '';
    for (let i = 0; i < maxArray; i++) {
        offerCard = document.createElement("div");
        offerCard.classList.add("offerCard");
        const postCard = document.createElement("p");
        const cityCard = document.createElement("p");
        const offerLink = document.createElement("a");
        postCard.classList.add("postCard");
        cityCard.classList.add("cityCard");
        offerLink.classList.add("offerLink");

        postCard.textContent = data[i].intitule_poste;
        cityCard.textContent = data[i].ville;
        offerLink.href = data[i].url_reponse;
        offerLink.textContent = "Voir l'offre";

        offerCard.append(postCard);
        offerCard.append(cityCard);
        offerCard.append(offerLink);
        cards.append(offerCard);
        messagesBot.append(cards);

        offerCard.display = "block";
        bodyBot.scrollTop = bodyBot.scrollHeight;
    }
    return cards;
}

/* =========== BOUTONS SOUS LES OFFRES ========== */

// Réaction du clique sur les boutons sous les offres
function choiceButtonAfterOffers(data) {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];

    for (choice of lastResponse.children) {
        (function (choice) {
            choice.addEventListener("click", function () {

                for (const b of lastResponse.children) {
                    if (!choice.textContent.includes("Voir plus")) {
                        b.style.cursor = "auto";
                        b.disabled = true;
                        b.classList.add("no-hover");
                    }
                }

                choice.classList.add("visited");

                if (choice.textContent.includes("Retour")) {
                    returnButton();
                } else if (choice.textContent.includes("Recommencer")) {
                    startAgainButton();
                }

            },);
        })(choice)
    }
}

/* =========== BOUTONS SI PAS D'OFFRES ========== */

function choiceButtonIfNoResult() {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];

    for (choice of lastResponse.children) {
        (function (choice) {
            choice.addEventListener("click", function () {

                for (const b of lastResponse.children) {
                    b.disabled = true;
                }

                choice.classList.add("visited");

                if (choice.textContent.includes("Retour")) {
                    returnButton();
                } else if (choice.textContent.includes("Recommencer")) {
                    startAgainButton();
                } else if (choice.textContent.includes("inscris")) {
                    for (const b of lastResponse.children) {
                        b.disabled = false;
                    }
                }
            },);
        })(choice)
    }
}

/* =========== FONCTIONNALITES DES BOUTONS ========== */

// Bouton qui permet de retourner à la question précédente
function returnButton() {

    const lastResponse = document.getElementsByClassName("choicesBot")[document.getElementsByClassName("choicesBot").length - 1];
    const lastCards = document.getElementsByClassName("cards")[document.getElementsByClassName("cards").length - 1];
    const lastQuestion = document.getElementsByClassName("messageBot")[document.getElementsByClassName("messageBot").length - 1];
    const lastUserResponse = document.getElementsByClassName("responsesUser")[document.getElementsByClassName("responsesUser").length - 1];

    let secondLastQuestion = document.getElementsByClassName("messageBot")[document.getElementsByClassName("messageBot").length - 2];

    getLoader();

    window.setTimeout(function () {
        responses = undefined;
        lastResponse.remove();
        if (lastCards !== undefined) {
            lastCards.remove();
        }
        // Activation de l'input et suppression de la dernière réponse utilisateur seulement si cette dernière existe et si l'avant dernière question concerne le poste
        if (lastUserResponse !== undefined && secondLastQuestion.textContent.includes("poste")) {
            lastUserResponse.remove();
            inputBot.disabled = false;
        }
        lastQuestion.remove();
        if (selectedJob === undefined && postDoesntExist >= 3) {
            secondLastQuestion.remove();
        }
        // Activation des dernier boutons seulement si l'avant dernière question ne concerne pas le poste
        if (!secondLastQuestion.textContent.includes("poste")) {
            activateButtons();
        }
        removeLoader();
    }, 2000);
}

// Bouton qui permet de recommencer la recherche
function startAgainButton() {
    let choicesElements = document.getElementsByClassName("choicesBot");
    let questionsElements = document.getElementsByClassName("messageBot");
    const userResponses = document.getElementsByClassName("responsesUser");
    const lastCards = document.getElementsByClassName("cards")[document.getElementsByClassName("cards").length - 1];
    getLoader();

    selectedContracts = [];
    window.setTimeout(async function () {
        if (lastCards !== undefined) {
            lastCards.remove();
        }
        responses = undefined;
        for (let i = choicesElements.length - 1; i >= 1; i--) {
            choicesElements[i].remove();
        }
        for (let i = questionsElements.length - 1; i >= 2; i--) {
            questionsElements[i].remove();
        }
        for (let i = userResponses.length - 1; i >= 0; i--) {
            userResponses[i].remove();
        }

        activateButtons();
        removeLoader();
        postDoesntExist = 1;
    }, 2000);
}

function createLink(buttonToReplace, link) {

    let a = document.createElement("a");
    a.href = link;
    a.innerText = buttonToReplace.innerText;
    a.classList.add("choices");
    a.style.display = "block";
    a.target = "_blank";

    buttonToReplace.replaceWith(a);
}

function codeSectorValue() {

    switch (selectedSector) {
        case "Agence": codeSecteur = 14; break;
        case "Agriculture": codeSecteur = 2; break;
        case "Agroalimentaire": codeSecteur = 3; break;
        case "BTP": codeSecteur = 4; break;
        case "Commerce": codeSecteur = 5; break;
        case "Evenementiel": codeSecteur = 6; break;
        case "Hotellerie/Restauration": codeSecteur = 7; break;
        case "Industrie": codeSecteur = 8; break;
        case "Medical": codeSecteur = 9; break;
        case "Tertiaire": codeSecteur = 10; break;
        case "Transport logistique": codeSecteur = 11; break;
        case "Travaux publics": codeSecteur = 12; break;
        case "Grande distribution": codeSecteur = 13; break;
    }
}