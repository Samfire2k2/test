/* =========== BOUTON ET APPARITION ========== */

// Récupération des éléments par leurs id dans des variables
const bubble = document.getElementById("bubble");
const button = document.getElementById("button");
const boobot = document.getElementById("boobot");

// Apparition du bouton au bout de 1,5 secondes
window.setTimeout(function () {
    button.style.visibility = "visible";
}, 1500);

// Apparition de la bullle de message au bout de 2,5 secondes
window.setTimeout(function () {
    bubble.style.visibility = "visible";
}, 2500);

// Disparition de la bulle de message au bout de 12 secondes
window.setTimeout(function () {
    bubble.style.display = "none";
}, 12000);

// Sur l'évènement de passage de sourie, je rentre dans la fonction handleDisapearingButton
button.addEventListener("mouseover", handleDisapearingBubble);

// Au passage de la sourie sur le bouton, je fais disparaître la bulle de message
function handleDisapearingBubble() {
    bubble.style.visibility = "hidden";
}

