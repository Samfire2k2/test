/* =========== CREATION DES MESSAGES ========== */

// Création et affichage de message avec vérification d'unicité du message
function createMessageChecked(message) {
    // Création du paragraphe qui contiendra la question proposée par le bot et ajout d'une classe
    const messageElement = document.createElement("p");
    messageElement.classList.add("messageBot");

    // Vérification que la question qui vient de bdd ne soit pas déjà présente dans le DOM, si elle est déjà présente, ne rien retourner (dans le cas d'une réouverture du chatbot)
    for (question of messageBot) {
        // Dans la vérification, il faut enlever les emoji du message qu'on lui donne car sinon elle ne fonctionne pas car l'élément du DOM qu'on récupère ne contient pas d'emoji
        if (message.replace(/🙂|✍|✔|👋|😉/g, "") === question.textContent) {
            return;
        }
    }

    // Ajout du message à l'élément créé, placement dans le DOM et affichage
    messageElement.textContent = message;
    messagesBot.append(messageElement);
    messageElement.style.display = "block";
    // Placement de la scrollbar en bas à l'apparition du message
    bodyBot.scrollTop = bodyBot.scrollHeight;

    removeLoader();
}

let messageDisplay = false;
// Création de message sans vérification d'unicité du message
function createMessage(message) {

    if (!messageDisplay) {

        messageDisplay = true;
        
        const messageElement = document.createElement("p");
        messageElement.classList.add("messageBot");
        messageElement.textContent = message;
        messagesBot.append(messageElement);
        messageElement.style.display = "block";
        bodyBot.scrollTop = bodyBot.scrollHeight;

        removeLoader();
        return messageElement;
    }
}