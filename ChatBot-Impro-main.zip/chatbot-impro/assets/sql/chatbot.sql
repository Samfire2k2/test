-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 09 mai 2023 à 11:57
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `chatbot`
--

-- --------------------------------------------------------

--
-- Structure de la table `contract`
--

CREATE TABLE `contract` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `contract`
--

INSERT INTO `contract` (`id`, `type`) VALUES
(1, 'CDI'),
(2, 'CDD'),
(3, 'Intérim'),
(4, 'CDI Intérim'),
(5, 'Apprentissage'),
(6, 'Freelance'),
(7, 'Stage'),
(8, 'Franchise'),
(9, 'Contractuel'),
(10, 'V.I.E'),
(11, 'Saisonnier');

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `id` int(11) UNSIGNED NOT NULL,
  `entitled` varchar(255) NOT NULL,
  `step` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `question`
--

INSERT INTO `question` (`id`, `entitled`, `step`) VALUES
(1, 'Bonjour et bienvenue 👋, je suis Boo et je suis la pour filtrer les offres qui vous correspondent afin de vous aider dans votre recherche d’emploi! 😉', '1'),
(2, 'Pour commencer, dans quel secteur d’activité souhaitez vous postuler ?', '2'),
(3, 'Donnez moi le nom de la ville dans laquelle vous souhaitez travailler ?', '3'),
(4, '¯\\_(ツ)_/¯ Je n’ai pas compris votre demande, voulez-vous bien reformuler, s’il vous plait', '3.a'),
(5, 'Si j’ai bien compris, vous recherchez dans la ville de Nantes dans le département Loire Atlantique ? 🤔', '3.b'),
(6, 'D\'accord, dans ce cas merci de me repréciser le nom de la ville dans laquelle vous souhaitez travailler ?', '3.c'),
(7, 'Très bien, à combien de km s’étend votre recherche autour de cette ville ? 🚗', '4'),
(8, 'D’accord, maintenant j’aimerais que vous me spécifiez le/s type/s de contrat que vous recherchez ? Sélectionnez un ou plusieurs contrats et cliquez sur \'Valider\'📝', '5'),
(9, 'Quel poste souhaitez-vous occuper, plus précisément ?', '6'),
(10, 'Voici les résultats correspondant à votre demande ✅', '6.a'),
(11, '¯\\_(ツ)_/¯ Je n’ai pas compris le nom du poste, voulez-vous bien le reformuler, s’il vous plait', '6.b'),
(12, '¯\\_(ツ)_/¯ Aucun résultat correspondant à votre demande', '6.c'),
(13, 'J’ai bien pris en compte votre demande. ✔ Maintenant, que souhaitez vous faire ?', '7'),
(14, 'D’accord. 🙂 Maintenant que souhaitez vous faire ?', '8'),
(15, 'C’est noté ! ✍ Que souhaitez-vous faire maintenant ?', '9'),
(16, 'D’accord. 🙂 Maintenant que voulez-vous faire ?', '10'),
(17, 'C’est noté ! ✍ Ensuite que voulez-vous faire?', '11'),
(18, 'Votre demande est prise en compte. ✔ Poursuivons, que voulez-vous faire maintenant ?', '12'),
(19, 'Que souhaitez-vous faire maintenant ? 🙂', '13');

-- --------------------------------------------------------

--
-- Structure de la table `question_response`
--

CREATE TABLE `question_response` (
  `id` int(10) UNSIGNED NOT NULL,
  `question_id` int(11) NOT NULL,
  `response_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `question_response`
--

INSERT INTO `question_response` (`id`, `question_id`, `response_id`) VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3),
(4, 2, 4),
(5, 2, 5),
(6, 2, 6),
(7, 2, 7),
(8, 2, 8),
(9, 2, 9),
(10, 2, 10),
(11, 2, 11),
(12, 2, 12),
(13, 2, 13),
(14, 14, 14),
(15, 14, 15),
(16, 14, 16),
(17, 13, 14),
(18, 13, 15),
(19, 13, 16),
(20, 15, 16),
(21, 15, 15),
(22, 15, 14),
(23, 16, 14),
(24, 16, 15),
(25, 16, 16),
(26, 17, 14),
(27, 17, 15),
(28, 17, 16),
(29, 18, 14),
(30, 18, 15),
(31, 18, 16),
(32, 19, 14),
(33, 19, 15),
(34, 19, 16),
(35, 5, 17),
(36, 5, 18),
(37, 7, 19),
(38, 7, 20),
(39, 7, 21),
(40, 7, 22),
(41, 7, 23),
(43, 8, 25),
(44, 8, 26),
(45, 8, 27),
(46, 8, 28),
(47, 8, 29),
(49, 8, 31),
(53, 8, 35),
(54, 10, 37),
(55, 10, 38),
(56, 10, 39),
(57, 12, 37),
(58, 12, 38),
(60, 12, 40),
(61, 12, 41),
(62, 8, 36);

-- --------------------------------------------------------

--
-- Structure de la table `response`
--

CREATE TABLE `response` (
  `id` int(11) UNSIGNED NOT NULL,
  `choices` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `response`
--

INSERT INTO `response` (`id`, `choices`) VALUES
(1, 'Agence'),
(2, 'Agriculture'),
(3, 'Agroalimentaire'),
(4, 'Evenementiel'),
(5, 'Grande distribution'),
(6, 'Hôtellerie/Restauration'),
(7, 'Tertiaire'),
(8, 'Transport logistique'),
(9, 'Travaux publics'),
(10, 'Médical'),
(11, 'Commerce'),
(12, 'Industrie'),
(13, 'BTP'),
(14, 'Afficher les résultats correspondants'),
(15, 'Affiner ma recherche'),
(16, 'Modifier ma réponse ✍'),
(17, 'Oui ✅'),
(18, 'Non ❌'),
(19, '10'),
(20, '20'),
(21, '30'),
(22, '40'),
(23, '50'),
(25, 'Intérim'),
(26, 'CDD'),
(27, 'CDI'),
(28, 'CDI Intérimaire'),
(29, 'Alternance'),
(31, 'Stage'),
(35, 'Saisonnier'),
(36, 'Valider'),
(37, 'Retour'),
(38, 'Recommencer ma recherche'),
(39, 'Voir plus'),
(40, 'Je m\'inscris et je me fais recontacter par une agence'),
(41, 'Ou prenez contact avec nous au 00.00.00.00.00');

-- --------------------------------------------------------

--
-- Structure de la table `visitor`
--

CREATE TABLE `visitor` (
  `id` int(11) UNSIGNED NOT NULL,
  `sector` varchar(50) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `department` varchar(75) DEFAULT NULL,
  `radius` varchar(10) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `visitor`
--

INSERT INTO `visitor` (`id`, `sector`, `city`, `department`, `radius`, `job`, `created_at`) VALUES
(1, 'Informatique', 'Montaigu', 'Vendée', '50 km', 'Développeur web', '2023-03-02 14:00:12'),
(2, 'Médical', 'Paris', 'Ile de France', '10 km', 'Médecin', '2023-03-02 14:01:46'),
(3, 'grande distribution', 'Dijon', 'Côte-d\'Or', '30 km', 'Préparation de commande', '2023-03-02 14:03:58'),
(4, 'commerce', 'Montaigu', 'Vendée', '20 km', 'Hôtesse de caisse', '2023-03-02 14:04:57'),
(5, 'Hôtellerie / Restauration', 'Paris', 'Ile de France', '30 km', 'Hôte d\'accueil', '2023-03-02 14:06:40'),
(6, 'Hôtellerie / Restauration', 'Nantes', 'Loire-Atlantique', '10 km', 'Serveur', '2023-03-02 14:07:25'),
(7, 'Médical', 'Nantes', 'Loire-Atlantique', '100 km', 'Aide soignant', '2023-03-02 14:08:10'),
(8, 'Médical', 'Lyon', 'Rhône', '10 km', 'Médecin', '2023-03-02 14:09:29'),
(9, 'Informatique', 'Montaigu', 'Vendée', '200 km', 'Design UI', '2023-03-02 14:11:07'),
(10, 'Informatique', 'Clisson', 'Loire-Atlantique', '50 km', 'Administrateur réseau', '2023-03-02 14:11:47'),
(11, 'Industrie', 'Nantes', 'Loire-Atlantique', '20 km', 'Agent polyvalent', '2023-03-02 14:14:18'),
(12, 'Industrie', 'grenoble', 'Isère', '30 km', 'Agent polyvalent', '2023-03-02 14:15:17'),
(13, 'Commerce', 'Montaigut', 'Puy-de-Dôme', '30km', NULL, '2023-03-06 08:48:58');

-- --------------------------------------------------------

--
-- Structure de la table `visitor_contract`
--

CREATE TABLE `visitor_contract` (
  `id` int(10) UNSIGNED NOT NULL,
  `visitor_id` int(11) NOT NULL,
  `contract_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `visitor_contract`
--

INSERT INTO `visitor_contract` (`id`, `visitor_id`, `contract_id`) VALUES
(1, 1, 2),
(2, 1, 6),
(4, 2, 1),
(5, 2, 3),
(7, 3, 2),
(8, 3, 3),
(9, 3, 4),
(10, 4, 2),
(11, 4, 3),
(13, 5, 1),
(14, 6, 1),
(15, 6, 2),
(16, 6, 11),
(17, 7, 2),
(18, 7, 6),
(19, 7, 11),
(20, 8, 1),
(21, 8, 2),
(22, 8, 7),
(23, 9, 6),
(24, 10, 6),
(25, 13, 1),
(26, 13, 7),
(27, 13, 11);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `question_response`
--
ALTER TABLE `question_response`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_QuestionHas` (`response_id`),
  ADD KEY `FK_ResponsesHas` (`question_id`);

--
-- Index pour la table `response`
--
ALTER TABLE `response`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `visitor_contract`
--
ALTER TABLE `visitor_contract`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `FK_VisitorSelects` (`visitor_id`),
  ADD KEY `FK_ContractSelects` (`contract_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `visitor`
--
ALTER TABLE `visitor`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `visitor_contract`
--
ALTER TABLE `visitor_contract`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
