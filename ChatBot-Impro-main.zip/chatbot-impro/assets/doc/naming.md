# Convention de nommages

Variables : camelCase

Branches : Anglais

Commit : Français

Commentaires : Français