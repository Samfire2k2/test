# Algorithmie

Arrivée sur la page  
    -  apparition du bouton au bout de 1.5 secondes  
    -  apparition de la bulle de message une seconde après

Au passage de la sourie  
    - Disparition de la bulle  
    - grossissement du bouton  

Au clique sur le bouton,
    - affichage du chatbot déployé avec apparition de ses deux premiers messages automatique  
        - le message de bienvenue (1)  
        - la première étape qui correspond à la demande du secteur d'activité(2.a)), au bout de 0.5 secondes  

Proposition des différents secteurs d'activité  

Selection d'un secteur par l'utilisateur  

Au clique de l'utilisateur, la question suivante apparaît  

Proposition du chatbot "Voulez-vous?"  
    - Si l'utilisateur choisi d'afficher les résultats  
        Proposition des offres d'emplois du secteur sélectionné  
    - Sinon si l'utilisateur choisi d'affiner la recherche  
        On passe à la question suivante  
    - Sinon si il choisi de modifier la réponse  
        La question "Voulez-vous" s'efface  
        Retour à la question précédente  

Au choix d'affiner la recherche, le chatbot demande la localisation

L'utilisateur entre le nom de la ville  
    => Connexion API  
    => Requête API  
        - Si l'api n'a pas trouvé le nom de la ville  
            le chatbot demande de reformuler  
        - Sinon si l'api a trouvé le nom de la ville  
            le chatbot reformule avec le nom du département pour confirmation de l'utilisateur  
                - Si non redemande du chatbot du nom de la ville  
                - Si oui = Question suivante (proposition du chatbot "Voulez-vous")  

Proposition du chatbot "Voulez-vous?"  
    - Si l'utilisateur choisi d'afficher les résultats  
        Proposition des offres d'emplois du secteur sélectionné  
    - Sinon si l'utilisateur choisi d'affiner la recherche  
        On passe à la question suivante  
    - Sinon si il choisi de modifier la réponse  
        La question "Voulez-vous" s'efface  
        Retour à la question précédente  

Au choix d'affiner la recherche, le chatbot demande le rayon

Proposition du chatbot des choix de rayon possibles

L'utilisateur sélectionne un rayon

Au clique sur le choix:  
Proposition du chatbot "Voulez-vous?"  
    - Si l'utilisateur choisi d'afficher les résultats  
        Proposition des offres d'emplois du secteur sélectionné  
    - Sinon si l'utilisateur choisi d'affiner la recherche  
        On passe à la question suivante  
    - Sinon si il choisi de modifier la réponse  
        La question "Voulez-vous" s'efface  
        Retour à la question précédente  

Au choix d'affiner la recherche, le chatbot demande le type de contrat  

Proposition du chatbot des choix de contrat possibles
    L'utilisateur peut selectionner entre une à plusieurs réponses  
    et cliquer sur le bouton "Valider" pour passer à la question suivante  

Au clique sur le choix:  
Proposition du chatbot "Voulez-vous?"  
    - Si l'utilisateur choisi d'afficher les résultats  
        Proposition des offres d'emplois du secteur sélectionné  
    - Sinon si l'utilisateur choisi d'affiner la recherche  
        On passe à la question suivante  
    - Sinon si il choisi de modifier la réponse  
        La question "Voulez-vous" s'efface  
        Retour à la question précédente  

Au choix d'affiner la recherche, le chatbot demande l'intitulé du poste  

L'utilisateur rentre le nom du poste  

Requêtes à la base de données pour vérifier l'intitulé du poste  
    - Si le nom du poste ne correspond à aucune donnée  
        Demande de reformulation  
    - Sinon si il y a des résultats
        Affichage des offres d'emplois
    - Sinon  
        Proposition du chatbot de retourner à la question précédente
            Demade du nom du poste
        de recommencer la recherche  
            Demande du secteur d'activité
        inscription  
            Redirection sur la page d'inscription  
        prise de contact  
            Numéro disponible  
