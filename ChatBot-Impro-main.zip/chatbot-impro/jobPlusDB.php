<?php

// Connexion à la base de données JobPlus
$wpdb_external = new wpdb("readOnlyJobPlus", "M66m%M2f@wdHR7gN", "jobplus", "192.168.99.21");

// Route permettant de récupérer les offres par secteur
function add_route_offers_sorted_by_sectors_api()
{
    register_rest_route('api/job', 'offre/secteur', array(
        'methods' => 'GET',
        'callback' => 'search_offers_by_sector',
        'args' => array(
            'secteur' => array(
                'type' => 'string',
                'required' => true,
            ),
        ),
    ));
}

function search_offers_by_sector(WP_REST_Request $request)
{
    global $wpdb_external;
    $secteur = $request->get_param('secteur');
    $query = $wpdb_external->prepare(
        "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse
        FROM job_base_offres jbo
        JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id
        WHERE jrs.libelle = %s
        AND jbo.publiee = 1
        AND jbo.publiee_site_carriere = 1
        ORDER BY jbo.id DESC;",
        $secteur
    );
    $results = $wpdb_external->get_results($query);
    return $results;
}

// Route permettant de récupérer les offres par secteur et par localisation
function add_route_offers_sorted_by_location_api()
{
    register_rest_route('api/job', 'offre/ville', array(
        'methods' => 'POST',
        'callback' => 'search_offers_by_location',
        'args' => array(
            'secteur' => array(
                'type' => 'string',
                'required' => true,
            ),
            'codesPostaux' => array(
                'type' => 'array',
                'required' => true
            )
        ),
    ));
}

function search_offers_by_location(WP_REST_Request $request)
{
    global $wpdb_external;
    $secteur = $request->get_param('secteur');
    $postcode = $request->get_param('codesPostaux');

    $postcode_str = "'" . implode("', '", $postcode) . "'";

    $query = $wpdb_external->prepare(
        "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse, jbo.code_postal, jrrd.libelle_departement as departement
        FROM job_base_offres jbo
        JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id
        JOIN job_ref_regions_departements jrrd ON jrrd.code_departement = LEFT(jbo.code_postal, 2)
        WHERE jrs.libelle = %s  
        AND jbo.code_postal IN ($postcode_str)
        AND jbo.publiee = 1
        AND jbo.publiee_site_carriere = 1
        ORDER BY jbo.id DESC;",
        $secteur
    );

    $results = $wpdb_external->get_results($query);
    return $results;
}

// Route permettant de récupérer les offres par secteur, par localisation et par contrats
function add_route_offers_sorted_by_contracts_api()
{
    register_rest_route('api/job', 'offre/contrats', array(
        'methods' => 'POST',

        'callback' => 'search_offers_by_contracts',
        'args' => array(
            'secteur' => array(
                'type' => 'string',
                'required' => true,
            ),
            'codesPostaux' => array(
                'type' => 'array',
                'required' => true
            ),
            'contrats' => array(
                'type' => 'array',
                'required' => true
            )
        ),
    ));
}

function search_offers_by_contracts(WP_REST_Request $request)
{
    global $wpdb_external;
    $secteur = $request->get_param('secteur');
    $postcode = $request->get_param('codesPostaux');
    
    $postcode_str = "'" . implode("', '", $postcode) . "'";

    $contracts = $request->get_param('contrats');
    $contracts_str = "'" . implode("', '", $contracts) . "'";
    $query = $wpdb_external->prepare(
        "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse, jrrd.libelle_departement as departement
        FROM job_base_offres jbo 
        JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id 
        JOIN job_ref_regions_departements jrrd ON jrrd.code_departement = LEFT(jbo.code_postal, 2) 
        JOIN job_ref_contrats jrc ON jbo.id_type_contrat = jrc.id 
        WHERE jrs.libelle = %s 
        AND jbo.code_postal IN ($postcode_str)
        AND jrc.libelle IN ($contracts_str)
        AND jbo.publiee = 1
        AND jbo.publiee_site_carriere = 1
        ORDER BY jbo.id DESC;",
        $secteur
    );

    $results = $wpdb_external->get_results($query);
    return $results;
}

// Route permettant de récupérer les offres par secteur, par localisation par contrats et par intitulé de poste
function add_route_offers_by_job_title_api()
{
    register_rest_route('api/job', 'offre/poste', array(
        'methods' => 'POST',
        'callback' => 'search_offers_by_job_title',
        'args' => array(
            'secteur' => array(
                'type' => 'string',
                'required' => true,
            ),
            'codesPostaux' => array(
                'type' => 'array',
                'required' => true
            ),
            'contrats' => array(
                'type' => 'array',
                'required' => true
            ),
            'poste' => array(
                'type' => 'string',
                'required' => true
            )
        ),
    ));
}

function search_offers_by_job_title(WP_REST_Request $request)
{
    global $wpdb_external;
    $secteur = $request->get_param('secteur');
    $postcode = $request->get_param('codesPostaux');
    $contracts = $request->get_param('contrats');
    $post = $request->get_param('poste');

    $postcode_str = "'" . implode("', '", $postcode) . "'";
    $contracts_str = "'" . implode("', '", $contracts) . "'";
    
    $query = $wpdb_external->prepare(
        "SELECT jbo.intitule_poste, jbo.ville, jbo.url_reponse , jrrd.libelle_departement as departement
        FROM job_base_offres jbo 
        JOIN job_ref_specialites jrs ON jbo.id_specialite = jrs.id 
        JOIN job_ref_regions_departements jrrd ON jrrd.code_departement = LEFT(jbo.code_postal, 2) 
        JOIN job_ref_contrats jrc ON jbo.id_type_contrat = jrc.id 
        WHERE jrs.libelle = %s
        AND jbo.code_postal IN ($postcode_str)
        AND jrc.libelle IN ($contracts_str)
        AND jbo.intitule_poste LIKE %s
        AND jbo.publiee = 1
        AND jbo.publiee_site_carriere = 1
        ORDER BY jbo.id DESC;",
        $secteur,
        "%" . $post . "%"
    );

    $results = $wpdb_external->get_results($query);
    return $results;
}

// Route permettant de vérifier si un poste est présent dans la base de données
function add_route_check_post_libelle_api()
{
    register_rest_route('api/job', 'poste', array(
        'methods' => 'GET',
        'callback' => 'check_post_libelle',
        'args' => array(
            'poste' => array(
                'type' => 'string',
                'required' => true,
            ),
        ),
    ));
}

function check_post_libelle(WP_REST_Request $request)
{
    global $wpdb_external;
    $post = $request->get_param('poste');
    $query = $wpdb_external->prepare("SELECT libelle
    FROM job_ref_offres_qualifications 
    WHERE libelle LIKE %s ", "%" . $post . "%");
    $results = $wpdb_external->get_results($query);
    return $results;
}

// Route permettant de voir tous les noms de postes existants dans la base de données (Route de test, non utile au projet)
function add_route_all_post_libelle_api()
{
    register_rest_route('api/job', 'poste/intitule', array(
        'methods' => 'GET',
        'callback' => 'all_libelles'
    ));
}

function all_libelles()
{
    global $wpdb_external;
    $query = $wpdb_external->prepare(
        "SELECT * 
    FROM job_ref_offres_qualifications;"
    );
    $results = $wpdb_external->get_results($query);
    return $results;
}

// Initialisation des routes API
add_action('rest_api_init', 'add_route_all_post_libelle_api');
add_action('rest_api_init', 'add_route_check_post_libelle_api');
add_action('rest_api_init', 'add_route_offers_sorted_by_sectors_api');
add_action('rest_api_init', 'add_route_offers_sorted_by_location_api');
add_action('rest_api_init', 'add_route_offers_sorted_by_contracts_api');
add_action('rest_api_init', 'add_route_offers_by_job_title_api');
