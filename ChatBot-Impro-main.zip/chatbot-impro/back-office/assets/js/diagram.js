const app = {

  init: function() {
    console.log('je suis chargé');
    // app.homeChart();
  },

  // homeChart: function() {
  //   const ctx = document.getElementById('myChart');
  
  //   new Chart(ctx, {
  //     type: 'bar',
  //     data: {
  //       labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
  //       datasets: [{
  //         label: '# of Votes',
  //         data: [12, 29, 3, 5, 2, 3],
  //         borderWidth: 3,
  //         borderColor: 'black',
  //         backgroundColor: 'White'
  //       }]
  //     },
  //     options: {
  //       scales: {
  //         y: {
  //           beginAtZero: true
  //         }
  //       }
  //     }
  //   });
  // }
}
document.addEventListener('DOMContentLoaded', app.init);