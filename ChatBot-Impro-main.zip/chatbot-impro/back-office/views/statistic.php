<?php generate_header() ?>
<?php generate_footer() ?>