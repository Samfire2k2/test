<?php generate_header() ?>
<h1>Bienvenue dans les paramètres du chatbot</h1>
<p id="home-text">Dans ces paramètres vous avez la possibilité de pouvoir accéder aux statistiques du chatbot afin de voir l'évolution de son utilisation dans le temps et d'autres paramètres importants selon ce que vous voulez savoir.</p>
<a id="link-button" href="<?php echo admin_url('admin.php?page=statistiques_chatbot'); ?>">Voir les statistiques</a>
<?php generate_footer() ?>