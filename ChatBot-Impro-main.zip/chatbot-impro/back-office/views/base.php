<?php
function generate_header()
{
?>
    <div class="wrap">
        <section id="header">
            <div id="logo">
                <img id="image" src="<?= plugin_url_button() ?>" alt="bot">
            </div>
            <h1 id="main-title">Paramètres du chatbot</h1>
            <?php if ($_GET['page'] == 'statistiques_chatbot') { ?>
                <a href="<?php echo admin_url('admin.php?page=statistiques_chatbot'); ?>" style="pointer-events: none">
                <style>
                    .tab-stat {
                        background: white;
                    }
                    .tab-stat:hover {
                        cursor: initial;
                        background: white;
                    }
                </style>
            <?php } else { ?>
            <a  class="a-tab" href="<?php echo admin_url('admin.php?page=statistiques_chatbot'); ?>">
            <?php } ?>
                <div class="tab-stat">statistiques</div>

            </a>
        </section>
        <section id="body">
        <?php
    }

    function generate_footer()
    {
        ?>
        </section>
    </div>

<?php
    }
?>