<!-- Import de la police d'écriture -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 128 128%22><text y=%221.2em%22 font-size=%2296%22>⚫️</text></svg>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- <script async
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2TDFIvUAMYGfVCYaD_igYhAFxKylfX4o&libraries=places&callback=initAutocomplete" defer>
</script> -->

<!-- Chatbot non déployé = Bouton et bulle de message -->
<div id="bot_button" class="hidden">
    <div id="bubble" class="boo_bottom_right boo_close_message">
        <p class="message">Bonjour, je fais parti de la tribu,<br> en quoi puis-je vous aider ?</p>
    </div>

    <div id="button" class="boo_bottom_right boo_button" onclick="onClickInBot()">
        <img id="image" src="<?= plugin_url_button() ?>" alt="bot">
    </div>
</div>

<!-- Chatbot déployé -->
<div id="boobot">

    <!-- Header du chatbot -->
    <div id="headerBot">
        <div id="headerTitle">
            <img id="bot" src="<?= plugin_url_chatbot() ?>" alt="bot">
            <h4>Boo Bot</h4>
        </div>
        <div id="headerImage">
            <img id="close" src="<?= plugin_url_close() ?>" alt="bot" onclick="onClickInClosingCross()">
        </div>
    </div>

    <!-- Body du bot -->
    <div id="bodyBot">
        <div id="messagesBot">
        </div>
    </div>

    <!-- Loader whith dots -->
    <div class="snippet" data-title="dot-pulse">
        <div class="stage">
            <div class="dot-pulse"></div>
        </div>
    </div>

    <!-- Footer du chatbot -->
    <form action="" id="botForm">
        <div id="footerBot">
            <input type="text" id="inputBot" onkeyup="javascript:verifInput()">
            <button type="submit" id="send" onmouseup="javascript:verifInput()">
                <img id="arrow" src="<?= plugin_url_arrow() ?>" alt="bot">
            </button>
        </div>
    </form>

</div>