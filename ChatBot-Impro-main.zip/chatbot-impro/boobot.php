<?php

/**
 * @package Chatbot Boo Bot
 * @version 1.0.0
 */
/*
Plugin Name: Chatbot Boo Bot
Plugin URI: http://wordpress.org/plugins/chatbot/
Description: Un plugin qui permet d'implenter un chatbot à ma page Wordpress
Author: Morgane Rabiller
Version: 1.0.0
*/

require_once("jobPlusDB.php");
require_once("villes-voisines.php");

// Disponibilité du JS et au CSS sur toutes les pages
function enqueue_main_bot()
{
    wp_enqueue_script('main-bot', plugin_dir_url(__FILE__) . 'assets/js/main-bot.js', true);
}

function enqueue_data_bot()
{
    wp_enqueue_script('data-bot', plugin_dir_url(__FILE__) . 'assets/js/data-bot.js', true);
}

function enqueue_loader_bot()
{
    wp_enqueue_script('loader-bot', plugin_dir_url(__FILE__) . 'assets/js/loader-bot.js', true);
}

function enqueue_button_bot()
{
    wp_enqueue_script('button-bot', plugin_dir_url(__FILE__) . 'assets/js/button-bot.js', true);
}

function enqueue_api_gouv()
{
    wp_enqueue_script('api-gouv', plugin_dir_url(__FILE__) . 'assets/js/api-gouv.js', true);
}

function enqueue_api_chatbot()
{
    wp_enqueue_script('api-chatbot', plugin_dir_url(__FILE__) . 'assets/js/api-chatbot.js', true);
}

function enqueue_new_message_bot()
{
    wp_enqueue_script('new-message-bot', plugin_dir_url(__FILE__) . 'assets/js/new-message-bot.js', true);
}

function enqueue_new_choices_bot()
{
    wp_enqueue_script('new-choices-bot', plugin_dir_url(__FILE__) . 'assets/js/new-choices-bot.js', true);
}

function enqueue_new_user_message()
{
    wp_enqueue_script('new-user-message', plugin_dir_url(__FILE__) . 'assets/js/new-user-message.js', true);
}

function enqueue_new_cards()
{
    wp_enqueue_script('new-cards', plugin_dir_url(__FILE__) . 'assets/js/new-cards.js', true);
}

function enqueue_style_bot()
{
    wp_enqueue_style('style-bot', plugins_url('assets/css/style-bot.css', __FILE__), 'all');
}

function call_page()
{
    require_once 'index-bot.php';
}

add_action('wp_head', 'enqueue_main_bot');
add_action('wp_head', 'enqueue_button_bot');
add_action('wp_enqueue_scripts', 'enqueue_data_bot');
add_action('wp_enqueue_scripts', 'enqueue_loader_bot');
add_action('wp_enqueue_scripts', 'enqueue_api_gouv');
add_action('wp_enqueue_scripts', 'enqueue_api_chatbot');
add_action('wp_enqueue_scripts', 'enqueue_new_message_bot');
add_action('wp_enqueue_scripts', 'enqueue_new_choices_bot');
add_action('wp_enqueue_scripts', 'enqueue_new_user_message');
add_action('wp_enqueue_scripts', 'enqueue_new_cards');
add_action('wp_enqueue_scripts', 'enqueue_style_bot');
add_action('wp_footer', 'call_page');

// Disponibilité des images SVG sur toutes les pages
function plugin_url_button()
{
    return plugin_dir_url(__FILE__) . 'assets/images/svg/botbutton.svg';
}
function plugin_url_chatbot()
{
    return plugin_dir_url(__FILE__) . 'assets/images/svg/chatbot.svg';
}
function plugin_url_close()
{
    return plugin_dir_url(__FILE__) . 'assets/images/svg/close-window.svg';
}
function plugin_url_arrow()
{
    return plugin_dir_url(__FILE__) . 'assets/images/svg/right-arrow.svg';
}

// Chargement d'Axios
function load_axios()
{
    wp_enqueue_script('axios', plugin_dir_url(__FILE__) . 'node_modules/axios/dist/axios.min.js', array(), '0.19.2', true);
}
add_action('wp_enqueue_scripts', 'load_axios');

// Requêtes SQL
function search_all_questions()
{
    global $wpdb;
    $results = $wpdb->get_results("SELECT * FROM question");
    return $results;
}

function search_question_by_step(WP_REST_Request $request)
{
    global $wpdb;
    $step = $request->get_param('step');
    $query = $wpdb->prepare("SELECT * FROM question WHERE step =%d ", $step);
    $results = $wpdb->get_results($query);
    return $results;
}

function search_question_response_by_id(WP_REST_Request $request)
{
    global $wpdb;
    $id = $request->get_param('id');
    $query = $wpdb->prepare("
    SELECT q.id, q.entitled, q.step, r.choices
    FROM question AS q
    INNER JOIN question_response AS q_r
    ON q.id = q_r.question_id
    INNER JOIN response AS r
    ON q_r.response_id = r.id
    WHERE q.id =%d ", $id);
    $results = $wpdb->get_results($query);

    $question = array();
    $choices = array();
    foreach ($results as $result) {
        $question['entitled'] = $result->entitled;
        $choices[] = $result->choices;
    }
    $response = array(
        'entitled' => $question['entitled'],
        'choices' => $choices,
    );
    if (empty($choices)) {
        $response['choices'] = null;
    }
    return $response;
    // return $results;
}

function search_random_question()
{
    global $wpdb;
    $results = $wpdb->get_results(
        "SELECT *
        FROM question
        WHERE id BETWEEN 13 AND 19
        ORDER BY RAND()
        LIMIT 1"
    );
    return $results;
}

function add_new_search(WP_REST_Request $request)
{
    global $wpdb;
    $sector = $request->get_param('sector');
    $city = $request->get_param('city');
    $department = $request->get_param('department');
    $radius = $request->get_param('radius');
    $job = $request->get_param('job');

    $wpdb->insert(
        'visitor',
        array(
            'sector' => $sector,
            'city' => $city,
            'department' => $department,
            'radius' => $radius,
            'job' => $job
        ),
        array('%s', '%s', '%s', '%s')
    );

    // Récupérer l'ID du visiteur qui vient d'être inséré
    $visitor_id = $wpdb->insert_id;

    $types = $request->get_param('types');

    // Exécuter la requête avec les types sélectionnés
    $table_contract = 'contract';
    $table_visitor_contract = 'visitor_contract';

    if (!empty($types)) {
        $types_string = "'" . implode("','", $types) . "'";
        $wpdb->query($wpdb->prepare("
            INSERT INTO $table_visitor_contract (visitor_id, contract_id)
            SELECT %d, id FROM $table_contract WHERE type IN ($types_string)
        ", $visitor_id));
    }
}

// Routes personnalisées API Wordpress
function add_route_questions_api()
{
    register_rest_route('bot/api', '/questions', array(
        'methods' => 'GET',
        'callback' => 'search_all_questions'
    ));
}

function add_route_question_by_step_api()
{
    register_rest_route('bot/api', '/questions/etape/(?P<step>\d+)', array(
        'methods' => 'GET',
        'callback' => 'search_question_by_step'
    ));
}

function add_route_question_response_api()
{
    register_rest_route('bot/api', 'questions/(?P<id>\d+)/reponses', array(
        'methods' => 'GET',
        'callback' => 'search_question_response_by_id'
    ));
}

function add_route_random_questions_api()
{
    register_rest_route('bot/api', 'questions/random', array(
        'methods' => 'GET',
        'callback' => 'search_random_question'
    ));
}

// Route d'insertion des statistiques par recherche
function add_route_new_data()
{
    register_rest_route('api/bot', 'creation/visiteur', array(
        'methods' => 'POST',
        'callback' => 'add_new_search'
    ));
}

// Initialisation des routes API Wordpress
add_action('rest_api_init', 'add_route_questions_api');
add_action('rest_api_init', 'add_route_question_by_step_api');
add_action('rest_api_init', 'add_route_question_response_api');
add_action('rest_api_init', 'add_route_random_questions_api');
add_action('rest_api_init', 'add_route_new_data');
// ------------------


/* BACK-OFFICE */

// Chargement du JS, du lien CDN de chartjs et du CSS
function add_cdn_chartjs()
{
    wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '4.2.1');
}

function enqueue_file_chartjs()
{
    wp_enqueue_script('file_chartjs', plugin_dir_url(__FILE__) . 'back-office/assets/js/diagram.js', true);
}

function enqueue_style_back_office()
{
    wp_enqueue_style('style-back', plugins_url('back-office/assets/css/style-back.css', __FILE__), 'all');
}

// Ajout d'un onglet chatbot pour les reglages du chatbot dans le back-office de Wordpress
function chatbotstat_add_menu_dasboard()
{

    add_menu_page(

        __("Statistiques du chatbot", "chatbot"), // texte de la balise <title>

        __("Chatbot", "chatbotstat"),  // titre de l'option de menu

        "manage_options", // droits requis pour voir l'option de menu

        "home_param_chatbot", // slug

        "chatbotHome_create_configuration_page" // fonction de rappel pour créer la page

    );
}

function chatbotstat_add_submenu_dasboard()
{
    add_submenu_page(
        'home_param_chatbot',
        
        __("Statistiques du chatbot", "chatbotstat"), // texte de la balise <title>
        
        __("Statistiques", "chatbotstat"),  // titre de l'option de menu
        
        "manage_options", // droits requis pour voir l'option de menu
        
        "statistiques_chatbot", // slug
        
        "chatbotstat_create_configuration_page" // fonction de rappel pour créer la page
        
    );
    
}

function chatbotHome_create_configuration_page()
{

    global $title;   // titre de la page du menu, tel que spécifié dans la fonction add_menu_page

    include_once('back-office/views/base.php');
    include_once('back-office/views/home.php');
}

function chatbotstat_create_configuration_page() {
    
    global $title;
    
    include_once('back-office/views/base.php');
    include_once('back-office/views/statistic.php');

}

// Enlèvement de la phrase par défaut "Merci de faire de WordPress votre outil de création de contenu." dans le footer de la page
function remove_wordpress_message()
{
    global $pagenow;
    if ($pagenow == 'admin.php' && isset($_GET['page']) && ($_GET['page'] == 'home_param_chatbot' || $_GET['page'] == 'statistiques_chatbot')) {
        add_filter('admin_footer_text', '__return_false');
        add_action('admin_enqueue_scripts', 'enqueue_style_back_office');
        add_action('admin_enqueue_scripts', 'add_cdn_chartjs');
        add_action('admin_enqueue_scripts', 'enqueue_file_chartjs');
    }
}

add_action("admin_menu", "chatbotstat_add_menu_dasboard");
add_action("admin_menu", "chatbotstat_add_submenu_dasboard");
add_action('admin_init', 'remove_wordpress_message');
